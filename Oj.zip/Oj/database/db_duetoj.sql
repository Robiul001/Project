-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 06, 2020 at 07:38 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_duetoj`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(50) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `name`, `email`, `password`, `status`) VALUES
(1, 'Zahid Robin', 'robin@gmail.com', '202cb962ac59075b964b07152d234b70', 1),
(2, 'Robiul Islam', 'robiul@gmail.com', '202cb962ac59075b964b07152d234b70', 0),
(3, 'Pranta Saha', 'pranta@gmail.com', '202cb962ac59075b964b07152d234b70', 0),
(7, 'Md. Monzurul Amin Ifath', 'monzurulamin10@gmail.com', '202cb962ac59075b964b07152d234b70', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contests`
--

CREATE TABLE `tbl_contests` (
  `cid` int(11) NOT NULL,
  `cname` varchar(255) NOT NULL,
  `cdate` date NOT NULL,
  `cstime` time NOT NULL,
  `cetime` time NOT NULL,
  `uniName` varchar(255) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_contests`
--

INSERT INTO `tbl_contests` (`cid`, `cname`, `cdate`, `cstime`, `cetime`, `uniName`, `status`) VALUES
(1, 'Intra DUET Programming Contest', '2020-01-26', '09:00:00', '12:00:00', 'Dhaka University of Engineering &amp; Technology(DUET)', 1),
(3, 'DIU TAKE-OFF PROGRAMMING CONTEST, FALL 2020', '2020-01-27', '09:00:00', '13:00:00', 'Dhaka International University(DIU).', 1),
(4, 'ICPC DHAKA REGIONAL 2020 ORGANIZED BY SEU', '2020-01-28', '09:00:00', '12:00:00', 'Southest University(SEU)', 0),
(5, 'UITS INTER UNIVERSITY PROGRAMMING CONTEST, 2020', '2020-03-10', '09:00:00', '12:00:00', 'University of Information Technology &amp; Sciences(UITS)', 0),
(6, 'ICPC DHAKA REGIONAL PRELIMINARY CONTEST, 2020 HOSTED BY DHAKA ENGINEERING UNIVERSITY', '2020-01-28', '04:00:00', '15:00:00', 'Dhaka Engineering University(DUET)', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_language`
--

CREATE TABLE `tbl_language` (
  `LID` int(11) NOT NULL,
  `language` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_language`
--

INSERT INTO `tbl_language` (`LID`, `language`) VALUES
(1, 'C'),
(2, 'GNU C++11 5.1.0'),
(3, 'GNU C++17 7.3.0');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_problemset`
--

CREATE TABLE `tbl_problemset` (
  `pID` int(11) NOT NULL,
  `cID` int(11) NOT NULL,
  `pName` varchar(255) NOT NULL,
  `timeLimit` int(11) NOT NULL,
  `memoryLimit` int(11) NOT NULL,
  `content` text NOT NULL,
  `totalTestcase` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_problemset`
--

INSERT INTO `tbl_problemset` (`pID`, `cID`, `pName`, `timeLimit`, `memoryLimit`, `content`, `totalTestcase`) VALUES
(1, 1, 'A. Watermelon', 1, 64, '&lt;p&gt;One hot summer day Pete and his friend Billy decided to buy a watermelon. They chose the biggest and the ripest one, in their opinion. After that the watermelon was weighed, and the scales showed&amp;nbsp;&lt;em&gt;w&lt;/em&gt;&amp;nbsp;kilos. They rushed home, dying of thirst, and decided to divide the berry, however they faced a hard problem.&lt;/p&gt;\r\n\r\n&lt;p&gt;Pete and Billy are great fans of even numbers, that&amp;#39;s why they want to divide the watermelon in such a way that each of the two parts weighs even number of kilos, at the same time it is not obligatory that the parts are equal. The boys are extremely tired and want to start their meal as soon as possible, that&amp;#39;s why you should help them and find out, if they can divide the watermelon in the way they want. For sure, each of them should get a part of positive weight.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;strong&gt;Input&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;The first (and the only) input line contains integer number&amp;nbsp;&lt;em&gt;w&lt;/em&gt;&amp;nbsp;(1&amp;thinsp;&amp;le;&amp;thinsp;&lt;em&gt;w&lt;/em&gt;&amp;thinsp;&amp;le;&amp;thinsp;100) &amp;mdash; the weight of the watermelon bought by the boys.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;strong&gt;Output&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Print&amp;nbsp;YES, if the boys can divide the watermelon into two parts, each of them weighing even number of kilos; and&amp;nbsp;NO&amp;nbsp;in the opposite case.&lt;/p&gt;', 2),
(2, 6, 'A. Almost Forgot to Welcome', 1, 1500, '&lt;p&gt;ICPC Dhaka Regional is the biggest programming competition in Bangladesh. Also the most anticipated one as well. Students from all the different universities storm their brains all year in preparation for this competition. You are now taking part in this competition, so a big congratulations to you.&lt;/p&gt;\r\n\r\n&lt;p&gt;Dhaka site is one of the biggest sites in ICPC. This year almost 1800 teams are participating in the competition. So in celebration, we are going to give you an easy problem to solve.&lt;/p&gt;\r\n\r\n&lt;p&gt;You have to write a program, which will print the line &amp;ldquo;Welcome to Dept. of CSE,DUET.&amp;rdquo; (without quotes).&lt;/p&gt;\r\n\r\n&lt;p&gt;Note: you can&amp;rsquo;t output anything other than the required output, and the line must end with a newline (&amp;lsquo; &amp;rsquo;). Take special care about spelling and case. If you alter any of those, you may not get accepted.&lt;/p&gt;\r\n\r\n&lt;p&gt;For your convenience, we are providing one sample program in C/C++ which prints &amp;ldquo;Bangladesh&amp;rdquo;. You just have to change the code to your requirement.&lt;/p&gt;\r\n\r\n&lt;pre&gt;\r\n&lt;code&gt;#include &amp;lt;stdio.h&amp;gt;\r\nint main()\r\n{\r\n    printf(&amp;quot;Bangladesh\r\n&amp;quot;);\r\n    return 0;\r\n}&lt;/code&gt;&lt;/pre&gt;', 1),
(3, 6, 'B. Theatre Square', 1, 256, '&lt;p&gt;Theatre Square in the capital city of Berland has a rectangular shape with the size&amp;nbsp;&lt;em&gt;n&lt;/em&gt;&amp;thinsp;&amp;times;&amp;thinsp;&lt;em&gt;m&lt;/em&gt;&amp;nbsp;meters. On the occasion of the city&amp;#39;s anniversary, a decision was taken to pave the Square with square granite flagstones. Each flagstone is of the size&amp;nbsp;&lt;em&gt;a&lt;/em&gt;&amp;thinsp;&amp;times;&amp;thinsp;&lt;em&gt;a&lt;/em&gt;.&lt;/p&gt;\r\n\r\n&lt;p&gt;What is the least number of flagstones needed to pave the Square? It&amp;#39;s allowed to cover the surface larger than the Theatre Square, but the Square has to be covered. It&amp;#39;s not allowed to break the flagstones. The sides of flagstones should be parallel to the sides of the Square.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;strong&gt;Input&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;The input contains three positive integer numbers in the first line:&amp;nbsp;&lt;em&gt;n&lt;/em&gt;,&amp;thinsp;&amp;thinsp;&lt;em&gt;m&lt;/em&gt;&amp;nbsp;and&amp;nbsp;&lt;em&gt;a&lt;/em&gt;&amp;nbsp;(1&amp;thinsp;&amp;le;&amp;thinsp;&amp;thinsp;&lt;em&gt;n&lt;/em&gt;,&amp;thinsp;&lt;em&gt;m&lt;/em&gt;,&amp;thinsp;&lt;em&gt;a&lt;/em&gt;&amp;thinsp;&amp;le;&amp;thinsp;10&lt;sup&gt;9&lt;/sup&gt;).&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;strong&gt;Output&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Write the needed number of flagstones.&lt;/p&gt;', 1),
(4, 6, 'C. Way Too Long Words', 1, 256, '&lt;p&gt;Sometimes some words like &amp;quot;localization&amp;quot; or &amp;quot;internationalization&amp;quot; are so long that writing them many times in one text is quite tiresome.&lt;/p&gt;\r\n\r\n&lt;p&gt;Let&amp;#39;s consider a word&amp;nbsp;too long, if its length is&amp;nbsp;&lt;strong&gt;strictly more&lt;/strong&gt;&amp;nbsp;than&amp;nbsp;10&amp;nbsp;characters. All too long words should be replaced with a special abbreviation.&lt;/p&gt;\r\n\r\n&lt;p&gt;This abbreviation is made like this: we write down the first and the last letter of a word and between them we write the number of letters between the first and the last letters. That number is in decimal system and doesn&amp;#39;t contain any leading zeroes.&lt;/p&gt;\r\n\r\n&lt;p&gt;Thus, &amp;quot;localization&amp;quot; will be spelt as &amp;quot;l10n&amp;quot;, and &amp;quot;internationalization&amp;raquo; will be spelt as &amp;quot;i18n&amp;quot;.&lt;/p&gt;\r\n\r\n&lt;p&gt;You are suggested to automatize the process of changing the words with abbreviations. At that all too long words should be replaced by the abbreviation and the words that are not too long should not undergo any changes.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;strong&gt;Input&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;The first line contains an integer&amp;nbsp;&lt;em&gt;n&lt;/em&gt;&amp;nbsp;(1&amp;thinsp;&amp;le;&amp;thinsp;&lt;em&gt;n&lt;/em&gt;&amp;thinsp;&amp;le;&amp;thinsp;100). Each of the following&amp;nbsp;&lt;em&gt;n&lt;/em&gt;&amp;nbsp;lines contains one word. All the words consist of lowercase Latin letters and possess the lengths of from&amp;nbsp;1&amp;nbsp;to&amp;nbsp;100&amp;nbsp;characters.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;strong&gt;Output&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Print&amp;nbsp;&lt;em&gt;n&lt;/em&gt;&amp;nbsp;lines. The&amp;nbsp;&lt;em&gt;i&lt;/em&gt;-th line should contain the result of replacing of the&amp;nbsp;&lt;em&gt;i&lt;/em&gt;-th word from the input data.&lt;/p&gt;', 2),
(5, 6, 'D. String Task', 2, 256, '&lt;p&gt;Petya started to attend programming lessons. On the first lesson his task was to write a simple program. The program was supposed to do the following: in the given string, consisting if uppercase and lowercase Latin letters, it:&lt;/p&gt;\r\n\r\n&lt;ul&gt;\r\n	&lt;li&gt;deletes all the vowels,&lt;/li&gt;\r\n	&lt;li&gt;inserts a character &amp;quot;.&amp;quot; before each consonant,&lt;/li&gt;\r\n	&lt;li&gt;replaces all uppercase consonants with corresponding lowercase ones.&lt;/li&gt;\r\n&lt;/ul&gt;\r\n\r\n&lt;p&gt;Vowels are letters &amp;quot;A&amp;quot;, &amp;quot;O&amp;quot;, &amp;quot;Y&amp;quot;, &amp;quot;E&amp;quot;, &amp;quot;U&amp;quot;, &amp;quot;I&amp;quot;, and the rest are consonants. The program&amp;#39;s input is exactly one string, it should return the output as a single string, resulting after the program&amp;#39;s processing the initial string.&lt;/p&gt;\r\n\r\n&lt;p&gt;Help Petya cope with this easy task.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;strong&gt;Input&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;The first line represents input string of Petya&amp;#39;s program. This string only consists of uppercase and lowercase Latin letters and its length is from&amp;nbsp;1&amp;nbsp;to&amp;nbsp;100, inclusive.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;strong&gt;Output&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Print the resulting string. It is guaranteed that this string is not empty.&lt;/p&gt;', 3),
(7, 1, 'B. Domino piling', 3, 256, '&lt;p&gt;You are given a rectangular board of&amp;nbsp;&lt;em&gt;M&lt;/em&gt;&amp;thinsp;&amp;times;&amp;thinsp;&lt;em&gt;N&lt;/em&gt;&amp;nbsp;squares. Also you are given an unlimited number of standard domino pieces of&amp;nbsp;2&amp;thinsp;&amp;times;&amp;thinsp;1&amp;nbsp;squares. You are allowed to rotate the pieces. You are asked to place as many dominoes as possible on the board so as to meet the following conditions:&lt;/p&gt;\r\n\r\n&lt;p&gt;1. Each domino completely covers two squares.&lt;/p&gt;\r\n\r\n&lt;p&gt;2. No two dominoes overlap.&lt;/p&gt;\r\n\r\n&lt;p&gt;3. Each domino lies entirely inside the board. It is allowed to touch the edges of the board.&lt;/p&gt;\r\n\r\n&lt;p&gt;Find the maximum number of dominoes, which can be placed under these restrictions.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;strong&gt;Input&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;In a single line you are given two integers&amp;nbsp;&lt;em&gt;M&lt;/em&gt;&amp;nbsp;and&amp;nbsp;&lt;em&gt;N&lt;/em&gt;&amp;nbsp;&amp;mdash; board sizes in squares (1&amp;thinsp;&amp;le;&amp;thinsp;&lt;em&gt;M&lt;/em&gt;&amp;thinsp;&amp;le;&amp;thinsp;&lt;em&gt;N&lt;/em&gt;&amp;thinsp;&amp;le;&amp;thinsp;16).&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;strong&gt;Output&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Output one number &amp;mdash; the maximal number of dominoes, which can be placed.&lt;/p&gt;', 2),
(8, 1, 'C. Football', 3, 256, '&lt;p&gt;Petya loves football very much. One day, as he was watching a football match, he was writing the players&amp;#39; current positions on a piece of paper. To simplify the situation he depicted it as a string consisting of zeroes and ones. A zero corresponds to players of one team; a one corresponds to players of another team. If there are at least&amp;nbsp;7&amp;nbsp;players of some team standing one after another, then the situation is considered dangerous. For example, the situation&amp;nbsp;00100110111111101&amp;nbsp;is dangerous and&amp;nbsp;11110111011101&amp;nbsp;is not. You are given the current situation. Determine whether it is dangerous or not.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;strong&gt;Input&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;The first input line contains a non-empty string consisting of characters &amp;quot;0&amp;quot; and &amp;quot;1&amp;quot;, which represents players. The length of the string does not exceed&amp;nbsp;100&amp;nbsp;characters. There&amp;#39;s at least one player from each team present on the field.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;strong&gt;Output&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Print &amp;quot;YES&amp;quot; if the situation is dangerous. Otherwise, print &amp;quot;NO&amp;quot;.&lt;/p&gt;', 2),
(9, 1, 'D. Helpful Maths', 2, 256, '&lt;p&gt;Xenia the beginner mathematician is a third year student at elementary school. She is now learning the addition operation.&lt;/p&gt;\r\n\r\n&lt;p&gt;The teacher has written down the sum of multiple numbers. Pupils should calculate the sum. To make the calculation easier, the sum only contains numbers 1, 2 and 3. Still, that isn&amp;#39;t enough for Xenia. She is only beginning to count, so she can calculate a sum only if the summands follow in non-decreasing order. For example, she can&amp;#39;t calculate sum 1+3+2+1 but she can calculate sums 1+1+2 and 3+3.&lt;/p&gt;\r\n\r\n&lt;p&gt;You&amp;#39;ve got the sum that was written on the board. Rearrange the summans and print the sum in such a way that Xenia can calculate the sum.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;strong&gt;Input&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;The first line contains a non-empty string&amp;nbsp;&lt;em&gt;s&lt;/em&gt;&amp;nbsp;&amp;mdash; the sum Xenia needs to count. String&amp;nbsp;&lt;em&gt;s&lt;/em&gt;&amp;nbsp;contains no spaces. It only contains digits and characters &amp;quot;+&amp;quot;. Besides, string&amp;nbsp;&lt;em&gt;s&lt;/em&gt;&amp;nbsp;is a correct sum of numbers 1, 2 and 3. String&amp;nbsp;&lt;em&gt;s&lt;/em&gt;&amp;nbsp;is at most 100 characters long.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;strong&gt;Output&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Print the new sum that Xenia can count.&lt;/p&gt;', 3),
(10, 3, 'A. Word Capitalization', 2, 256, '&lt;p&gt;Capitalization is writing a word with its first letter as a capital letter. Your task is to capitalize the given word.&lt;/p&gt;\r\n\r\n&lt;p&gt;Note, that during capitalization all the letters except the first one remains unchanged.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;strong&gt;Input&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;A single line contains a non-empty word. This word consists of lowercase and uppercase English letters. The length of the word will not exceed&amp;nbsp;10&lt;sup&gt;3&lt;/sup&gt;.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;strong&gt;Output&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;Output the given word after capitalization.&lt;/p&gt;', 2),
(11, 3, 'B. Boy or Girl', 3, 256, '&lt;p&gt;Those days, many boys use beautiful girls&amp;#39; photos as avatars in forums. So it is pretty hard to tell the gender of a user at the first glance. Last year, our hero went to a forum and had a nice chat with a beauty (he thought so). After that they talked very often and eventually they became a couple in the network.&lt;/p&gt;\r\n\r\n&lt;p&gt;But yesterday, he came to see &amp;quot;her&amp;quot; in the real world and found out &amp;quot;she&amp;quot; is actually a very strong man! Our hero is very sad and he is too tired to love again now. So he came up with a way to recognize users&amp;#39; genders by their user names.&lt;/p&gt;\r\n\r\n&lt;p&gt;This is his method: if the number of distinct characters in one&amp;#39;s user name is odd, then he is a male, otherwise she is a female. You are given the string that denotes the user name, please help our hero to determine the gender of this user by his method.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;strong&gt;Input&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;The first line contains a non-empty string, that contains only lowercase English letters &amp;mdash; the user name. This string contains at most 100 letters.&lt;/p&gt;\r\n\r\n&lt;p&gt;&lt;strong&gt;Output&lt;/strong&gt;&lt;/p&gt;\r\n\r\n&lt;p&gt;If it is a female by our hero&amp;#39;s method, print &amp;quot;CHAT WITH HER!&amp;quot; (without the quotes), otherwise, print &amp;quot;IGNORE HIM!&amp;quot; (without the quotes).&lt;/p&gt;', 2);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_submission`
--

CREATE TABLE `tbl_submission` (
  `subID` int(11) NOT NULL,
  `userID` varchar(55) NOT NULL,
  `author` varchar(55) NOT NULL,
  `pID` int(11) NOT NULL,
  `cID` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `language` varchar(55) NOT NULL,
  `verdict` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_submission`
--

INSERT INTO `tbl_submission` (`subID`, `userID`, `author`, `pID`, `cID`, `time`, `language`, `verdict`) VALUES
(1, 'IDPC_20_01', 'CDC_SoVaKK', 1, 1, '2020-01-27 07:45:31', 'GNU C++11 5.1.0', 'Wrong Answer'),
(2, 'IDPC_20_01', 'CDC_SoVaKK', 1, 1, '2020-01-27 07:47:32', 'GNU C++11 5.1.0', 'Wrong Answer'),
(3, 'IDPC_20_01', 'CDC_SoVaKK', 1, 1, '2020-01-27 07:48:11', 'GNU C++11 5.1.0', 'Wrong Answer'),
(4, 'IDPC_20_01', 'CDC_SoVaKK', 1, 1, '2020-01-27 07:55:00', 'GNU C++17 7.3.0', 'Wrong Answer'),
(5, 'IDPC_20_01', 'CDC_SoVaKK', 1, 1, '2020-01-27 07:55:40', 'GNU C++17 7.3.0', 'Accepted'),
(6, 'IDPC_20_01', 'CDC_SoVaKK', 1, 1, '2020-01-27 07:55:58', 'C', 'Compilation Error'),
(7, 'IDPC_20_03', 'DUET_Bright_Coder', 1, 1, '2020-01-27 08:27:24', 'GNU C++11 5.1.0', 'Accepted');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_testcase`
--

CREATE TABLE `tbl_testcase` (
  `tID` int(11) NOT NULL,
  `pID` int(11) NOT NULL,
  `cID` int(11) NOT NULL,
  `input` text NOT NULL,
  `output` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_testcase`
--

INSERT INTO `tbl_testcase` (`tID`, `pID`, `cID`, `input`, `output`) VALUES
(1, 1, 1, '8', 'YES'),
(2, 1, 1, '9', 'NO'),
(3, 3, 6, '6 6 4', '4'),
(4, 4, 6, 'word', 'word'),
(5, 4, 6, 'word', 'word'),
(6, 4, 6, 'internationalization', 'i18n'),
(7, 5, 6, 'tour', '.t.r'),
(8, 5, 6, 'Codeforces', '.c.d.f.r.c.s'),
(9, 5, 6, 'aBAcAba', '.b.c.b'),
(10, 5, 6, 'aBAcAba', '.b.c.b'),
(11, 5, 6, 'aBAcAba', '.b.c.b'),
(107, 7, 1, '2 4', '4'),
(108, 7, 1, '3 3', '4'),
(109, 8, 1, '001001', 'NO'),
(110, 8, 1, '00100110111111101', 'YES'),
(111, 9, 1, '3+2+1', '1+2+3'),
(112, 9, 1, '1+1+3+1+3', '1+1+1+3+3'),
(113, 9, 1, '2', '2'),
(114, 10, 3, 'ApPLe', 'ApPLe'),
(115, 10, 3, 'konjac', 'Konjac'),
(116, 11, 3, 'wjmzbmr', 'CHAT WITH HER!'),
(117, 11, 3, 'sevenkplus', 'CHAT WITH HER!');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_users`
--

CREATE TABLE `tbl_users` (
  `uID` int(11) NOT NULL,
  `teamName` varchar(55) NOT NULL,
  `email` varchar(55) NOT NULL,
  `uniName` varchar(255) NOT NULL,
  `userID` varchar(55) NOT NULL,
  `cID` int(11) NOT NULL,
  `password` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_users`
--

INSERT INTO `tbl_users` (`uID`, `teamName`, `email`, `uniName`, `userID`, `cID`, `password`) VALUES
(1, 'CDC_SoVaKK', 'rrp@gmail.com', 'Dhaka University of Engineering &amp; Technology(DUET)', 'IDPC_20_01', 1, 'XYTXQBCJVY'),
(3, 'DUET_CODE_WARRIOR', 'codeWarrior@gmail.com', 'Dhaka University of Engineering &amp; Technology(DUET)', 'IDPC_20_02', 3, 'LRNEKRTCPV'),
(4, 'DUET_Bright_Coder', 'robiul@gmail.com', 'Dhaka University of Engineering &amp; Technology(DUET).', 'IDPC_20_03', 1, 'MIKOMAUGJH');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_contests`
--
ALTER TABLE `tbl_contests`
  ADD PRIMARY KEY (`cid`);

--
-- Indexes for table `tbl_language`
--
ALTER TABLE `tbl_language`
  ADD PRIMARY KEY (`LID`);

--
-- Indexes for table `tbl_problemset`
--
ALTER TABLE `tbl_problemset`
  ADD PRIMARY KEY (`pID`);

--
-- Indexes for table `tbl_submission`
--
ALTER TABLE `tbl_submission`
  ADD PRIMARY KEY (`subID`);

--
-- Indexes for table `tbl_testcase`
--
ALTER TABLE `tbl_testcase`
  ADD PRIMARY KEY (`tID`);

--
-- Indexes for table `tbl_users`
--
ALTER TABLE `tbl_users`
  ADD PRIMARY KEY (`uID`),
  ADD UNIQUE KEY `userID` (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_contests`
--
ALTER TABLE `tbl_contests`
  MODIFY `cid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `tbl_language`
--
ALTER TABLE `tbl_language`
  MODIFY `LID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `tbl_problemset`
--
ALTER TABLE `tbl_problemset`
  MODIFY `pID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `tbl_submission`
--
ALTER TABLE `tbl_submission`
  MODIFY `subID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `tbl_testcase`
--
ALTER TABLE `tbl_testcase`
  MODIFY `tID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;
--
-- AUTO_INCREMENT for table `tbl_users`
--
ALTER TABLE `tbl_users`
  MODIFY `uID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
