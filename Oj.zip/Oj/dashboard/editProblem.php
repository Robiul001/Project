<?php
	$path = realpath(dirname(__FILE__));
	include_once('./inc/header.php');
	include_once('./inc/sidebar.php');
	include_once '../classes/Problemset.php';
	include_once '../classes/Contests.php';
	include_once '../classes/Testcase.php';
	include_once '../lib/Format.php';
	
	$ps = new Problemset();
	$fm = new Format();
	$ct = new Contests();
	$tc = new Testcase();
	if(!isset($_GET['cid']) || !isset($_GET['pid'])){
		echo "<script>window.location='viewContest.php'</script>";
	}
	$cid = $fm->validation($_GET['cid']);
	$pid = $fm->validation($_GET['pid']);
	
	if($_SERVER['REQUEST_METHOD']=="POST" && isset($_POST['update']))
	{
		$editProblem = $ps->updateProblem($_POST,$pid);
		/*if($editProblem){
			$deleteCase = $tc->deleteTestcase($pid);
		}
		$path = $path."/../dashboard/testcase/contest$cid/problem$pid/";
		$myfile  = 'in.txt';
		$fileDirectory = $path.$myfile;
		$handle  = fopen($fileDirectory,'a') or die('Can\'t open file: '.$myfile);
		ftruncate($handle,0);
		$data    = $_POST['totalTestcase'];
		fwrite($handle,$data); 
		fclose($handle);
		$myfile  = 'out.txt';
		$fileDirectory = $path.$myfile;
		$outHandle = fopen($fileDirectory,'a') or die('Can\'t open file: '.$myfile);
		ftruncate($outHandle,0);
		fclose($outHandle);*/
	}
	
	$selectProblem = $ps->selectSpecificProblemFromContest($pid,$cid);
	if($selectProblem){
		$selectProblem = $selectProblem->fetch_assoc();
	}
	
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h4 class="page-header" style="margin:20px 0 20px;color:#337ab7;">Edit Problem Set</h4>
				<form role="form" action="editProblem.php?cid=<?php echo $selectProblem['cID'] ?>&&pid=<?php echo $selectProblem['pID']; ?>" method="post">
                    <div class="form-group">
                        <label>Contest Name</label>
				<?php $contestSelect = $ct->selectContestByID($cid);
				if($contestSelect){$contestSelect = $contestSelect->fetch_assoc();} ?>
                        <input class="form-control" type="hidden" name="cID" value="<?php echo $contestSelect['cid']; ?>">
                        <input class="form-control" type="text" disabled value="<?php echo $contestSelect['cname']; ?>">
                    </div>
					<div class="form-group">
                        <label>Problem Name</label>
                        <input type="text" class="form-control" name="pName" value="<?php echo $selectProblem['pName'];?>">
                        <p class="help-block">Example - A.Watermelon.</p>
                    </div>
					<div class="form-group">
                        <label>Time Limit</label>
                        <input type="text" name="timeLimit" class="form-control" value="<?php echo $selectProblem['timeLimit'];?>">
                        <p class="help-block">Example - 3 (As Second).</p>
                    </div>
					<div class="form-group">
                        <label>Memory Limit</label>
                        <input name="memoryLimit" type="text" class="form-control" value="<?php echo $selectProblem['memoryLimit'];?>">
                        <p class="help-block">Example - 1 (As MegaByte).</p>
                    </div>
					<div class="form-group">
                        <label>Testcase For Contestant</label>
                        <input class="form-control" name="totalTestcase" value="<?php echo $selectProblem['totalTestcase'];?>">
                        <p class="help-block">Example - 50.</p>
                    </div>
					<div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" rows="8" name="content">
							<?php echo $selectProblem['content'];?>
						</textarea>
                    </div>
                    <button type="submit" name="update" class="btn btn-default">Update</button>
					<a href="viewProblemList.php?cid=<?php echo $selectProblem['cID']; ?>" class="btn btn-default">Back</a>
                </form>
        </div>
    </div>
    <?php if(isset($editProblem)){
			echo $editProblem;
	} ?>    
</div>




<?php
	include_once('./inc/footer.php');
?>