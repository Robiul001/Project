<?php
	include_once('./inc/header.php');
	include_once('./inc/sidebar.php');
	
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h4 class="page-header" style="margin:20px 0 20px;color:#337ab7;">Edit Testcase</h4>
				<form role="form">
                    <div class="form-group">
                        <label>Contest Name</label>
                        <input class="form-control" type="hidden" name="cID">
                        <input class="form-control" disabled value="Mock Test">
                    </div>
					<div class="form-group">
                        <label>Problem Name</label>
                        <input type="hidden" class="form-control" name="pID">
                        <input type="text" class="form-control" disabled name="pName" value="A.Watermelon">
                    </div>
					<div class="form-group">
                        <label>Input</label>
                        <input class="form-control" value="2">
                    </div>
					<div class="form-group">
                        <label>Output</label>
                        <input class="form-control" value="4">
                    </div>
                    <button type="submit" class="btn btn-default">Update</button>
                    <button type="reset" class="btn btn-default">Reset</button>
                </form>
        </div>
    </div>
           
</div>




<?php
	include_once('./inc/footer.php');
?>