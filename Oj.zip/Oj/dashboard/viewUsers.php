<?php
	$path = realpath(dirname(__FILE__));
	include_once('./inc/header.php');
	include_once('./inc/sidebar.php');
	include_once('../classes/Contests.php');
	include_once('../classes/User.php');
	include_once '../lib/Format.php';
	
	$fm = new Format();
	$ct = new Contests();
	$ur = new User();
	$cid     = $fm->validation($_GET['cid']);
	
	if(isset($_GET['delUser'])){
		$id = $_GET['delUser'];
		$dlUser = $ur->deleteUser($cid,$id);
		echo "<script>window.location='viewUsers.php?cid=$cid'</script>";
	}
?>
<div id="page-wrapper">
    <div class="row">
	<?php $result = $ct->selectContestByID($cid);
		if($result){$result = $result->fetch_assoc();} ?>
        <div class="col-lg-12">
            <h4 class="page-header" style="margin:20px 0 20px;color:#337ab7;">Team List For <?php echo $result['cname'] ?></h4>
        </div>
    </div>
	<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Team Data Table
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th class="text-center">SN</th>
                                        <th class="text-center">Teamname</th>
                                        <th class="text-center">University</th>
										<th class="text-center">User ID</th>
										<th class="text-center">Password</th>
                                        <th class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
						<?php
							$viewUsers = $ur->viewAllUsers($cid);
							if($viewUsers){
								$i=1;
								while($result = $viewUsers->fetch_assoc()){?>
                                    <tr class="odd gradeX">
                                        <td class="text-center"><?php echo $i++; ?></td>
                                        <td class="text-center"><?php echo $result['teamName']; ?></td>
                                        <td class="text-center"><?php echo $fm->textShorten($result['uniName'],45);?></td>
                                        <td class="text-center"><?php echo $result['userID'];?></td>
                                        <td class="text-center"><?php echo $result['password']; ?></td>
                                        <td class="text-center"><a href="editUser.php?uid=<?php echo $result['uID'] ?>&&cid=<?php echo $cid; ?>">Edit</a> || <a  onclick="return confirm('Are yor sure to delete this User!')" href="?cid=<?php echo $cid?>&&delUser=<?php echo $result['uID'];?>">Delete</a></td>
									</tr>
							<?php } }else{ ?>
									<tr class="odd gradeX">
										<td class="text-center" colspan="8">No User Create yet.</td>
									</tr>
							<?php } ?>
                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
           
</div>

		
		
   
<?php
	include_once('./inc/footer.php');
?>