<?php
	$path = realpath(dirname(__FILE__));
	include_once('./inc/header.php');
	include_once('./inc/sidebar.php');
	include_once('../classes/Contests.php');
	$ct = new Contests();
?>
<?php
	$ct = new Contests();
	if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['submit'])){
		$createContest = $ct->contestCreate($_POST);
		if($createContest){
			$id = $ct->lastID()->fetch_assoc();
			$id = $id['cid'];
			$createFolder = mkdir($path."/../dashboard/testcase/contest$id",0777);
			if(!$createFolder){
				$errmsg = "Check Testcase Folder ".$path."/testcase";
			}
		}
	}

?>

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h4 class="page-header" style="margin:20px 0 20px;color:#337ab7;">Create New Contest</h4>
				<form role="form" action="createContest.php" method="post">
                    <div class="form-group">
                        <label>Contest Name</label>
                        <input class="form-control" name="cname">
                        <p class="help-block">Example - Intra DUET Programming Contest.</p>
                    </div>
					<div class="form-group">
                        <label>Contest Date</label>
                        <input type="date" class="form-control" name="cdate">
                    </div>
					<div class="form-group">
                        <label>Contest Start Time</label>
                        <input type="text" class="form-control" name="cstime">
						<p class="help-block">24 Hour Format - 13:00</p>
                    </div>
					<div class="form-group">
                        <label>Contest End Time</label>
                        <input type="text" class="form-control" name="cetime">
						<p class="help-block">24 Hour Format - 15:30</p>
                    </div>
					<div class="form-group">
                        <label>University Name</label>
                        <input type="text" class="form-control" name="uniName">
                        <p class="help-block">Example - Dhaka University of Engineering & Technology(DUET).</p>
                    </div>
                    <button type="submit" name="submit" class="btn btn-default">Submit</button>
                    <button type="reset" class="btn btn-default">Reset</button>
                </form>
		</div>
    </div>
          <?php
			if(isset($createContest)){
				echo $createContest;
				if(isset($errmsg)){
					echo "<br>".$errmsg;
				}
			}
			?> 
</div>




<?php
	include_once('./inc/footer.php');
?>