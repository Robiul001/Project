<?php
	$path = realpath(dirname(__FILE__));
	include_once('./inc/header.php');
	include_once('./inc/sidebar.php');
	include_once('../classes/Contests.php');
	include_once('../lib/Format.php');
	$ct = new Contests();
	$fm = new Format();
	
	if(isset($_GET['delAction'])){
		$id         = $_GET['delAction'];
		/*For deleting Contest Folder*/
		/*Start*/
		$str = $path."/testcase/contest$id/";
		function deleteContestFolder($str){  
			if (is_file($str)) { 
				return unlink($str); 
			} 
			elseif (is_dir($str)) { 
				$scan = glob(rtrim($str, '/').'/*'); 
				foreach($scan as $index=>$path) {  
					deleteContestFolder($path); 
				} 
				return @rmdir($str); 
			} 
		}
		/*End*/
		deleteContestFolder($str);
		$delContest = $ct->deleteContest($id);
		echo "<script>window.location='viewContest.php'</script>";
		
	}
	if(isset($_GET['act'])){
		$actId = $_GET['act'];
		$actContest = $ct->activeContest($actId);
	}
	if(isset($_GET['deact'])){
		$deactId = $_GET['deact'];
		$deactContest = $ct->deactiveContest($deactId);
	}
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h4 class="page-header" style="margin:20px 0 20px;color:#337ab7;">View Contests</h4>
        </div>
    </div>
	<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Contests Data Table
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th class="text-center">SN</th>
                                        <th class="text-center">Name</th>
                                        <th class="text-center">Date</th>
                                        <th class="text-center">University</th>
                                        <th class="text-center">Action</th>
                                        <th class="text-center">Status</th>
                                    </tr>
                                </thead>
                                <tbody>
						<?php
							$viewContest = $ct->viewAlContest();
							if($viewContest){
								$i=1;
								while($result = $viewContest->fetch_assoc()){?>
                                    <tr class="odd gradeX">
                                        <td class="text-center"><?php echo $i++; ?></td>
                                        <td class="text-center"><?php echo $fm->textShorten($result['cname'],15);?></td>
                                        <td class="text-center"><?php echo date("Y-m-d",strtotime($result['cdate']));?></td>
                                        <td class="text-center"><?php echo $fm->textShorten($result['uniName'],15); ?></td>
                                        <td class="text-center"><a href="editContest.php?id=<?php echo $result['cid'];?>">Edit</a> || <a href="?delAction=<?php echo $result['cid'] ?>" onclick="return confirm('Are yor sure to delete this !')">Delete</a> || <a href="problemSet.php?cid=<?php echo $result['cid'] ?>">Problem Set</a> || <a href="viewProblemList.php?cid=<?php echo $result['cid'];?>">View Problem Lists</a></td>
										<td class="text-center">
										<?php if($result['status'] == '0'){ ?>
											<a href="?act=<?php echo $result['cid']; ?>">Activate</a>
										<?php }else{ ?>
											<a href="?deact=<?php echo $result['cid']; ?>">Deativate</a>
										<?php } ?>
										</td>
									</tr>
							<?php } }else{ ?>
									<tr class="odd gradeX">
										<td class="text-center" colspan="8">No Contests Create yet.</td>
									</tr>
							<?php } ?>
                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
           
</div>

		
		
   
<?php
	include_once('./inc/footer.php');
?>