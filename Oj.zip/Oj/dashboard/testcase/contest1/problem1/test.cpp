#include<bits/stdc++.h>
using namespace std;
int main(){
freopen("in.txt","r",stdin);
freopen("out.txt","w",stdout);
    int t;
    cin>>t;
    while(t--)
    {
        int a;
        cin>>a;
        if(a%2!=0 || a<3)
            cout<<"NO"<<endl;
        else
            cout<<"YES"<<endl;
    }
	return 0;
}