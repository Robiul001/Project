<?php
	include_once('./inc/header.php');
	include_once('./inc/sidebar.php');
	include_once '../classes/AdminLogin.php';
	
	$al = new AdminLogin();
?>
<?php
	if(isset($_GET['delAction'])){
		$id = $_GET['delAction'];
		$delAdmin = $al->deleteAdmin($id);
		echo "<script>window.location='viewAdmin.php'</script>";
	}
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h4 class="page-header" style="margin:20px 0 20px;color:#337ab7;">View Contests</h4>
        </div>
    </div>
	<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Contests Data Table
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th class="text-center">SN</th>
                                        <th class="text-center">Name</th>
                                        <th class="text-center">Email</th>
										
										<th class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
									<?php 
										$vAdmin = $al->viewAdmin();
										$i = 1;
										if($vAdmin){
										while($value = $vAdmin->fetch_assoc()){?>
											<tr class="odd gradeX">
												<td class="text-center"><?php echo $i++;?></td>
												<td class="text-center"><?php echo $value['name']?></td>
												<td class="text-center"><?php echo $value['email']?></td>
												<td class="text-center"><a href="editAdmin.php?id=<?php echo $value['id'] ?>">Edit</a> || <a href="?delAction=<?php echo $value['id'] ?>" onclick="return confirm('Are yor sure to delete this !')">Delete</a></td>
											</tr>
										<?php } } ?>
                                      
                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
           
</div>
<?php
	include_once('./inc/footer.php');
?>