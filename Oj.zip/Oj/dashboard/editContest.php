<?php
	include_once('./inc/header.php');
	include_once('./inc/sidebar.php');
	include_once('../classes/Contests.php');
	include_once '../lib/Format.php';
	$fm = new Format();
	$ct = new Contests();
?>
<?php
	if(!isset($_GET['id']) || $_GET['id'] == NULL){
		echo "<script>window.location='viewContest.php'</script>";
	}
	$id     = $fm->validation($_GET['id']);
	
	if($_SERVER['REQUEST_METHOD']=="POST" && isset($_POST['update']))
	{
		$upContest = $ct->updateContest($_POST,$id);
	}
	
	$result = $ct->selectContestByID($id);
	if($result){
		$result = $result->fetch_assoc();
	}
	
	
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h4 class="page-header" style="margin:20px 0 20px;color:#337ab7;">Edit Contest</h4>
				<form role="form" method="post" action="editContest.php?id=<?php echo $result['cid'];?>">
                    <div class="form-group">
                        <label>Contest Name</label>
                        <input class="form-control" name="cname" value="<?php echo $result['cname']; ?>">
                        <p class="help-block">Example - Intra DUET Programming Contest.</p>
                    </div>
					<div class="form-group">
                        <label>Contest Date</label>
                        <input type="date" class="form-control" name="cdate" value="<?php echo $result['cdate']; ?>">
                    </div>
					<div class="form-group">
                        <label>Contest Start Time</label>
                        <input type="text" class="form-control" name="cstime" value="<?php echo $result['cstime']; ?>">
						<p class="help-block">24 Hour Format - 13:00</p>
					</div>
					<div class="form-group">
                        <label>Contest End Time</label>
                        <input type="text" class="form-control" name="cetime" value="<?php echo $result['cetime']; ?>">
						<p class="help-block">24 Hour Format - 15:30</p>
					</div>
					<div class="form-group">
                        <label>University Name</label>
                        <input class="form-control" type="text" name="uniName" value="<?php echo $result['uniName']; ?>">
                        <p class="help-block">Example - Dhaka University of Engineering & Technology(DUET).</p>
                    </div>
                    <button type="submit" name="update" class="btn btn-default">Update</button>
					<a href="viewContest.php" class="btn btn-default">Back</a>
                </form>
        </div>
    </div>
       <?php
			if(isset($upContest)){
				echo $upContest;
			}
	   ?>    
</div>




<?php
	include_once('./inc/footer.php');
?>