<?php
	$path = realpath(dirname(__FILE__));
	include_once('./inc/header.php');
	include_once('./inc/sidebar.php');
	include_once '../classes/Problemset.php';
	include_once('../classes/Contests.php');
	include_once('../classes/User.php');
	include_once '../lib/Format.php';
	
	$ps = new Problemset();
	$fm = new Format();
	$ct = new Contests();
	$ur = new User();
	$cid     = $fm->validation($_GET['cid']);
	$uid     = $fm->validation($_GET['uid']);
?>
<?php
	if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['update'])){
		$upUser = $ur->updateUser($_POST,$cid,$uid);
	}
?>

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
		<?php $result = $ct->selectContestByID($cid);
				if($result){$result = $result->fetch_assoc();} ?>
            <h4 class="page-header" style="margin:20px 0 20px;color:#337ab7;">Update Team For <?php echo $result['cname'] ?></h4>
			<?php
				$uRetrieve = $ur->userRetrieve($cid,$uid);
				if($uRetrieve){$uRetrieve = $uRetrieve->fetch_assoc();}
			?>
				<form role="form" action="" method="post">
                    <div class="form-group">
                        <label>Team Name</label>
                        <input value="<?php echo $uRetrieve['teamName']; ?>" class="form-control" name="teamName">
                    </div>
					<div class="form-group">
                        <label>Email</label>
                        <input value="<?php echo $uRetrieve['email']; ?>" type="email" class="form-control" name="email">
                    </div>
					<div class="form-group">
                        <label>University Name</label>
                        <input value="<?php echo $uRetrieve['uniName']; ?>" type="text" class="form-control" name="uniName">
                    </div>
					<div class="form-group">
                        <label>User ID</label>
                        <input value="<?php echo $uRetrieve['userID']; ?>" type="text" class="form-control" name="userID">
                    </div>
                    <button type="submit" name="update" class="btn btn-default">Update</button>
                    <a class="btn btn-default" href="viewUsers.php?cid=<?php echo $cid; ?>">Back To Team List</a>
                </form>
		</div>
    </div>
          <?php
			if(isset($upUser)){
				echo $upUser;
			}
			?> 
</div>




<?php
	include_once('./inc/footer.php');
?>