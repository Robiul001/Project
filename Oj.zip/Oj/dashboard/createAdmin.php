<?php
	$path = realpath(dirname(__FILE__));
	include_once($path.'/inc/header.php');
	include_once($path.'/inc/sidebar.php');
	include_once ($path.'/../classes/AdminLogin.php');
	
	$al = new AdminLogin();
	
?>
<?php
	if($_SERVER['REQUEST_METHOD']=="POST" && isset($_POST['submit']))
	{
		$createAdmin = $al->adminCreate($_POST);
	}	
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h4 class="page-header" style="margin:20px 0 20px;color:#337ab7;">Create New Admin</h4>
				<form role="form" action="createAdmin.php" method="post">
                    <div class="form-group">
                        <label>User Name</label>
                        <input class="form-control" name="name">
                        <p class="help-block">Example - Abdur Rahim</p>
                    </div>
					<div class="form-group">
                        <label>Email</label>
                        <input class="form-control" type="email" name="email">
                        <p class="help-block">Example - abc12@gmail.com</p>
                    </div>
					<div class="form-group">
                        <label>Password</label>
                        <input type="password" class="form-control" name="password">
                    </div>
					<div class="form-group">
                        <label>Confirm Password</label>
                        <input type="password" class="form-control" name="re_pass">
                    </div>
                    <button type="submit" name="submit" class="btn btn-default">Submit</button>
                    <button type="reset" class="btn btn-default">Reset</button>
					<a href="viewAdmin.php" class="btn btn-default">Back</a>
                </form>
				<?php
					if(isset($createAdmin)){
						echo $createAdmin;
					}
				?>
		</div>
    </div> 
</div>




<?php
	include_once('./inc/footer.php');
?>