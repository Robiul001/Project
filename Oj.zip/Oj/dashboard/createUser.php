<?php
	$path = realpath(dirname(__FILE__));
	include_once('./inc/header.php');
	include_once('./inc/sidebar.php');
	include_once '../classes/Problemset.php';
	include_once('../classes/Contests.php');
	include_once('../classes/User.php');
	include_once '../lib/Format.php';
	
	$ps = new Problemset();
	$fm = new Format();
	$ct = new Contests();
	$ur = new User();
	$cid     = $fm->validation($_GET['cid']);
?>
<?php
	if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['submit'])){
		$crUser = $ur->createUser($_POST,$cid);
	}
?>

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
		<?php $result = $ct->selectContestByID($cid);
				if($result){$result = $result->fetch_assoc();} ?>
            <h4 class="page-header" style="margin:20px 0 20px;color:#337ab7;">Create Team For <?php echo $result['cname'] ?></h4>
				<form role="form" action="" method="post">
                    <div class="form-group">
                        <label>Team Name</label>
                        <input class="form-control" name="teamName">
                        <p class="help-block">Example - DUET_RRP</p>
                    </div>
					<div class="form-group">
                        <label>Email</label>
                        <input type="email" class="form-control" name="email">
                        <p class="help-block">Example - rrp@gmail.com</p>
                    </div>
					<div class="form-group">
                        <label>University Name</label>
                        <input type="text" class="form-control" name="uniName">
                        <p class="help-block">Example - Dhaka University of Engineering & Technology(DUET).</p>
                    </div>
					<div class="form-group">
                        <label>User ID</label>
                        <input type="text" class="form-control" name="userID">
                        <p class="help-block">Example - IDPC_20_100.</p>
                    </div>
                    <button type="submit" name="submit" class="btn btn-default">Submit</button>
                    <button type="reset" class="btn btn-default">Reset</button>
                </form>
		</div>
    </div>
          <?php
			if(isset($crUser)){
				echo $crUser;
			}
			?> 
</div>




<?php
	include_once('./inc/footer.php');
?>