<?php
	$path = realpath(dirname(__FILE__));
	include_once('./inc/header.php');
	include_once('./inc/sidebar.php');
	include_once '../classes/Problemset.php';
	include_once('../classes/Contests.php');
	include_once('../classes/Testcase.php');
	include_once '../lib/Format.php';
	
	$ps = new Problemset();
	$fm = new Format();
	$ct = new Contests();
	$tc = new Testcase();
	
	/*if(!isset($_GET['cid']) || $_GET['cid'] == NULL){
		echo "<script>window.location='viewContest.php'</script>";
	}*/
	$cid     = $fm->validation($_GET['cid']);
	$pid     = $fm->validation($_GET['pid']);
	//$myfile  = 'out.txt';
	$path = $path."/../dashboard/testcase/contest$cid/problem$pid/";
	//$fileDirectory = $path.$myfile;
	$tcCount = $tc->testcaseCount($pid,$cid)->fetch_assoc();
	if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['submit'])){
		$input = $_POST['input'];
		$output = $_POST['output'];
		$inputfile = $_FILES['inputfile']['name'];
		$outputfile = $_FILES['outputfile']['name'];
		if(!empty($input) && !empty($output) && !empty($inputfile) && !empty($outputfile)){
			$testcase   = $tc->createTestcase($_POST);
			$inputfile  = $path."in.txt";
			$outputfile = $path."judgeout.txt";
			move_uploaded_file($_FILES['inputfile']['tmp_name'],$inputfile);
			move_uploaded_file($_FILES['outputfile']['tmp_name'],$outputfile);	
		}else if(!empty($input) && !empty($output)){
			$testcase   = $tc->createTestcase($_POST);
		}else if(!empty($inputfile) && ($outputfile)){
			$inputfile  = $path."in.txt";
			$outputfile = $path."judgeout.txt";
			move_uploaded_file($_FILES['inputfile']['tmp_name'],$inputfile);
			move_uploaded_file($_FILES['outputfile']['tmp_name'],$outputfile);
			$fmsg = "<span class='success'>File Uploaded.</span>";
		}
		//echo "<script>window.location.reload()</script>";
			
	}
	
	
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h4 class="page-header" style="margin:20px 0 20px;color:#337ab7;">Create Testcase</h4>
			<form role="form" action="" method="post" enctype="multipart/form-data">
			<?php $value = $tc->contestAndProblemName($pid,$cid)->fetch_assoc();?>
                <div class="form-group">
                    <label>Contest Name</label>
                    <input class="form-control" type="hidden" value="<?php echo $value['cid']; ?>" name="cID">
                    <input class="form-control" disabled value="<?php echo $value['cname'] ?>">
                </div>
				<div class="form-group">
                    <label>Problem Name</label>
                    <input type="hidden" class="form-control" name="pID" value="<?php echo $value['pID'] ?>">
                    <input type="text" class="form-control" disabled name="pName" value="<?php echo $value['pName']; ?>">
                </div>
				<div class="form-group">
                    <label>Required Testcase</label>
					<input class="form-control" type="hidden" name="noTestcase" value="<?php echo $value['totalTestcase']-$line;?>">
                    <input class="form-control" disabled  value="<?php if($value['totalTestcase']-$tcCount['COUNT(pID)']>0){ echo $value['totalTestcase']-$tcCount['COUNT(pID)'];}else{ echo 0;}?>">   
                </div>
				<div class="form-group">
                    <label>Input</label>
                    <input class="form-control" type="text" name="input">
                </div>
				<div class="form-group">
                    <label>Output</label>
                    <input class="form-control" type="text" name="output">
                </div>
				<div class="form-group">
                    <label>Input File</label>
                    <input class="form-control" type="file" name="inputfile">
					<p class="help-block">Example - in.txt</p>
                </div>
				<div class="form-group">
                    <label>Output File</label>
                    <input class="form-control" type="file" name="outputfile">
					<p class="help-block">Example - out.txt</p>
				</div>
                <button type="submit" <?php if($value['totalTestcase']-$tcCount['COUNT(pID)'] <= 0)echo "disabled";?> class="btn btn-default" name="submit">Submit</button>
                <button type="reset" class="btn btn-default">Reset</button>
            </form>
        </div>
		<?php
			if(isset($testcase)){
				echo $testcase;
			}
			if(isset($fmsg)){
				echo $fmsg;
			}
		?>
    </div> 
</div>
<?php
	include_once('./inc/footer.php');
?>