<?php
	$path = realpath(dirname(__FILE__));
	include_once('./inc/header.php');
	include_once('./inc/sidebar.php');
	include_once '../classes/Problemset.php';
	include_once '../classes/Contests.php';
	include_once '../lib/Format.php';
	
	$ps = new Problemset();
	$fm = new Format();
	$ct = new Contests();
	$id = $fm->validation($_GET['cid']);
	$result = $ct->selectContestByID($id);
	if($result){
		$result = $result->fetch_assoc();
	}
	
	$getProblem = $ps->allProblemsByContestId($id);
	if(isset($_GET['delPid']) && isset($_GET['delCid'])){
		$delPid =$_GET['delPid'];
		$delCid =$_GET['delCid'];
		/*For deleting Contest Folder*/
		/*Start*/
		$str = $path."/testcase/contest$delCid/problem$delPid/";
		function deleteContestFolder($str){  
			if (is_file($str)) { 
				return unlink($str); 
			} 
			elseif (is_dir($str)) { 
				$scan = glob(rtrim($str, '/').'/*'); 
				foreach($scan as $index=>$path) {  
					deleteContestFolder($path); 
				} 
				return @rmdir($str); 
			} 
		}
		/*End*/
		deleteContestFolder($str);
		$delProblem = $ps->deleteProblemByID($delPid,$delCid);
		echo "<script>window.location='viewProblemList.php?cid=$delCid'</script>";
	}
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h4 class="page-header" style="margin:20px 0 20px;color:#337ab7;"><?php echo $result['cname']; ?></h4>
        </div>
    </div>
	<div class="row">
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            Problems Data Table
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                            <table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">
                                <thead>
                                    <tr>
                                        <th class="text-center">SN</th>
                                        <th class="text-center">Problem Name</th>
                                        <th class="text-center">Time Limit</th>
                                        <th class="text-center">Testcase</th>
                                        <th class="text-center">Description</th>
                                        <th class="text-center">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
					<?php
						if($getProblem){
							$i=1;
							while($value = $getProblem->fetch_assoc()){?>
                                    <tr class="odd gradeX">
                                        <td class="text-center"><?php echo $value['pID'] ?></td>
                                        <td class="text-center"><?php echo $value['pName']?></td>
                                        <td class="text-center"><?php echo $value['timeLimit']; ?></td>
                                        <td class="text-center"><?php echo $value['totalTestcase']; ?></td>
                                        <td class="text-center"><?php echo $fm->textShorten($value['content'],35); ?></td>
                                        <td class="text-center"><a href="editProblem.php?cid=<?php echo $value['cID'] ?>&&pid=<?php echo $value['pID']; ?>">Edit</a> || <a href="?delCid=<?php echo $value['cID'] ?>&&delPid=<?php echo $value['pID']; ?>" onclick="return confirm('Are yor sure to delete this !')">Delete</a> || <a href="createTestCase.php?cid=<?php echo $value['cID'] ?>&&pid=<?php echo $value['pID']; ?>">Create Testcase</a><!-- || <a href="viewTestCases.php?cid=<?php echo $value['cID'] ?>&&pid=<?php echo $value['pID']; ?>">View Testcases</a>--></td>
                                    </tr>
						<?php } }else{?>
									<tr>
										<td colspan="5" class="text-center">No Problems Create yet.</td>
									</tr>
						<?php } ?>     
                                </tbody>
                            </table>
                            <!-- /.table-responsive -->
                           
                        </div>
                        <!-- /.panel-body -->
                    </div>
                    <!-- /.panel -->
                </div>
                <!-- /.col-lg-12 -->
            </div>
           
</div>

		
		
   
<?php
	include_once('./inc/footer.php');
?>