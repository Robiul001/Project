<?php
	include_once('./inc/header.php');
	include_once('./inc/sidebar.php');
	include_once '../classes/AdminLogin.php';
	include_once '../lib/Format.php';
	
	$al = new AdminLogin();
	$fm = new Format();
?>
<?php
	if(!isset($_GET['id']) || $_GET['id'] == NULL){
		echo "<script>window.location='viewAdmin.php'</script>";
	}
	$id = $fm->validation($_GET['id']);
	
	if($_SERVER['REQUEST_METHOD']=="POST" && isset($_POST['update']))
	{
		$upAdmin = $al->updateAdmin($_POST,$id);
	}
	
	$result = $al->particularAdmin($id);
	if($result){
		$result = $result->fetch_assoc();
	}
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h4 class="page-header" style="margin:20px 0 20px;color:#337ab7;">Update Admin Profile</h4>
				<form role="form" action="editAdmin.php?id=<?php echo $result['id'] ?>" method="post">
                    <div class="form-group">
                        <label>User Name</label>
                        <input class="form-control" name="name" value="<?php echo $result['name']?>">
                    </div>
					<div class="form-group">
                        <label>Email</label>
                        <input class="form-control" type="email" name="email" value="<?php echo $result['email']?>">
                    </div>
					<div class="form-group">
                        <label>Password</label>
                        <input type="password" class="form-control" name="password">
                    </div>
					<div class="form-group">
                        <label>Confirm Password</label>
                        <input type="password" class="form-control" name="re_pass">
                    </div>
                    <button type="submit" name="update" class="btn btn-default">Update</button>
                    <button type="reset" class="btn btn-default">Reset</button>
					<a href="viewAdmin.php" class="btn btn-default">Back</a>
                </form>
		</div>
		
    </div>
          <?php
			if(isset($upAdmin)){
				echo $upAdmin;
			}
			?> 
</div>




<?php
	include_once('./inc/footer.php');
?>