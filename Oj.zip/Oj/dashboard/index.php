<?php
	include_once('./inc/header.php');
	include_once('./inc/sidebar.php');
	
?>

	<div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h4 class="page-header" style="margin:20px 0 20px;color:#337ab7;">Dashboard</h4>
					<h1 class="text-center" style="font-size:70px;color:#444;font-weight:bold;padding-top:40px">Welcome To Admin Panel</h1>
                </div>
            </div>
           
    </div>

		
		
   
<?php
	include_once('./inc/footer.php');
?>