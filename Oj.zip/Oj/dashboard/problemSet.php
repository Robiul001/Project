<?php
	$path = realpath(dirname(__FILE__));
	include_once('./inc/header.php');
	include_once('./inc/sidebar.php');
	include_once '../classes/Problemset.php';
	include_once('../classes/Contests.php');
	include_once '../lib/Format.php';
	
	$ps = new Problemset();
	$fm = new Format();
	$ct = new Contests();
	
	/*if(!isset($_GET['cid']) || $_GET['cid'] == NULL){
		echo "<script>window.location='viewContest.php'</script>";
	}*/
	$cid     = $fm->validation($_GET['cid']);
	
	if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['submit'])){
		$createProblem = $ps->problemsetCreate($_POST);
		if($createProblem){
			$id = $ps->lastID($cid)->fetch_assoc();
			$id = $id['pID'];
			$createFolder = mkdir($path."/../dashboard/testcase/contest$cid/problem$id",0777);
			if(!$createFolder){
				$errmsg = "Check Testcase Folder ".$path."/testcase/contest$cid/";
			}
		}
	}
?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h4 class="page-header" style="margin:20px 0 20px;color:#337ab7;">Create Problem Set</h4>
				<form role="form" action="" method="post">
                    <div class="form-group">
                        <label>Contest Name</label>
			<?php $result = $ct->selectContestByID($cid);
				if($result){$result = $result->fetch_assoc();} ?>
                        <input class="form-control" type="hidden" value="<?php echo $result['cid']; ?>" name="cID">
                        <input class="form-control" type="text" disabled value="<?php echo $result['cname'] ?>">
                    </div>
					<div class="form-group">
                        <label>Problem Name</label>
                        <input class="form-control" name="pName">
                        <p class="help-block">Example - A.Watermelon.</p>
                    </div>
					<div class="form-group">
                        <label>Time Limit</label>
                        <input class="form-control" name="timeLimit">
                        <p class="help-block">Example - 3 (As Second).</p>
                    </div>
					<div class="form-group">
                        <label>Memory Limit</label>
                        <input class="form-control" name="memoryLimit">
                        <p class="help-block">Example - 1 (As MegaByte).</p>
                    </div>
					<div class="form-group">
                        <label>Testcase For Contestant</label>
                        <input class="form-control" name="totalTestcase">
                        <p class="help-block">Example - 3.</p>
                    </div>
					<div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" rows="8" name="content"></textarea>
                    </div>
                    <button type="submit" class="btn btn-default" name="submit">Submit</button>
                    <button type="reset" class="btn btn-default">Reset</button>
                </form>
        </div>
    </div>
    <?php
			if(isset($createProblem)){
				echo $createProblem;
				if(isset($errmsg)){
					echo "<br>".$errmsg;
				}
			}
	?>
		   
</div>




<?php
	include_once('./inc/footer.php');
?>