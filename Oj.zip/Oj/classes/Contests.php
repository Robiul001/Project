<?php
	$path = realpath(dirname(__FILE__));
	include_once $path.'/../lib/Database.php';
	include_once $path.'/../lib/Format.php';
?>
<?php
	class Contests{
		private $db;
		private $fm;
		public function __construct(){
			$this->db = new Database();
			$this->fm = new Format();
		}
		
		public function contestCreate($data){
			$cname  = $this->fm->validation($data['cname']);
			$cdate  = $this->fm->validation($data['cdate']);
			$cstime = $this->fm->validation($data['cstime']);
			$cetime = $this->fm->validation($data['cetime']);
			$cdate  = date("Y-m-d",strtotime($cdate));
			$uniName=$this->fm->validation($data['uniName']);
			if(empty($cname) || empty($cdate) || empty($cstime) || empty($cetime) || empty($uniName)){
				$msg = "<span class='error'>Field Must Not be Empty!!!</span>";
				return $msg;
			}else{
				$sql    = "INSERT INTO tbl_contests (cname,cdate,cstime,cetime,uniName) 
				VALUES('$cname','$cdate','$cstime','$cetime','$uniName')";
				$result = $this->db->insert($sql);
				if($result){
					$msg = "<span class='success'>Contest Created Successfully.</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Contest Not Created.</span>";
					return $msg;
				}
			}
		}
		
		public function viewAlContest(){
			$sql    = "SELECT * FROM tbl_contests ORDER BY cid desc";
			$result = $this->db->select($sql);
			return $result; 
		}
		
		public function selectContestByID($id){
			$sql    = "SELECT * FROM tbl_contests WHERE cid='$id'";
			$result = $this->db->select($sql);
			return $result;
		}
		
		public function updateContest($data,$id){
			$cname  = $this->fm->validation($data['cname']);
			$cdate  = $this->fm->validation($data['cdate']);
			$cstime = $this->fm->validation($data['cstime']);
			$cetime = $this->fm->validation($data['cetime']);
			$cdate  = date("Y-m-d",strtotime($cdate));
			$uniName=$this->fm->validation($data['uniName']);
			if(empty($cname) || empty($cdate) || empty($cstime) || empty($cetime) || empty($uniName)){
				$msg = "<span class='error'>Field Must Not be Empty!!!</span>";
				return $msg;
			}else{
				$sql    = "UPDATE tbl_contests SET cname='$cname',cdate='$cdate',cstime='$cstime',cetime='$cetime',uniName='$uniName' WHERE cid='$id'";
				$result = $this->db->update($sql);
				if($result){
					$msg = "<span class='success'>Contest Updated Successfully.</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Contest Not Updated.</span>";
					return $msg;
				}
			}
		}
		
		public function deleteContest($id){
			$sql    = "DELETE FROM tbl_contests WHERE cid='$id'";
			$result = $this->db->delete($sql);
			if($result){
				$sql    = "DELETE FROM  tbl_problemset WHERE cid='$id'";
				$pdelete= $this->db->delete($sql);
			}
			return $result;
		}
		
		public function activeContest($actId){
			$sql 	= "UPDATE tbl_contests SET status='1' WHERE cid='$actId'";
			$result = $this->db->update($sql);
			return $result; 
		}
		
		public function deactiveContest($deactId){
			$sql    = "UPDATE tbl_contests SET status='0' WHERE cid='$deactId'";
			$result = $this->db->update($sql);
			return $result;
		}
		
		public function lastID(){
			$sql = "SELECT * FROM  tbl_contests
			WHERE cid = (SELECT MAX(cid) FROM  tbl_contests)";
			$result = $this->db->select($sql);
			return $result;
		}
		
		/*public function deleteContestFolder($str) {  
			if (is_file($str)) { 
				return unlink($str); 
			} 
			elseif (is_dir($str)) { 
				$scan = glob(rtrim($str, '/').'/*'); 
				foreach($scan as $index=>$path) {  
					deleteContestFolder($path); 
				} 
				return @rmdir($str); 
			} 
		}*/
		
		
		/*User Panel*/
		public function limitedContest(){
			$sql    = "SELECT *,CONCAT(cdate,' ',cstime) contestTime FROM tbl_contests WHERE status='1' ORDER BY cid desc LIMIT 5";
			$result = $this->db->select($sql);
			return $result;
		}
		
		public function viewAllActiveContest(){
			$sql    = "SELECT *,CONCAT(cdate,' ',cstime) contestTime FROM tbl_contests WHERE status='1' ORDER BY cid desc";
			$result = $this->db->select($sql);
			return $result;
		}
		
		public function getContestTime(){
			$sql = "SELECT cname,CONCAT(cdate,' ',cstime) contestTime FROM tbl_contests 
			WHERE (CONCAT(cdate,' ',cstime)) = (SELECT MIN(CONCAT(cdate,' ',cstime)) FROM tbl_contests 
			WHERE (CONCAT(cdate,' ',cstime)) > NOW() AND status=1)";
			$result = $this->db->select($sql);
			return $result;
		}
		
		public function languageSelection(){
			$sql = "SELECT * FROM tbl_language";
			$rst =$this->db->select($sql);
			return $rst;
		}
		
		public function submission($cid,$pid,$lang,$answer,$userID){
			$teamSql = "SELECT teamName FROM tbl_users WHERE userID='$userID'";
			$rst = $this->db->select($teamSql)->fetch_assoc();
			$teamName = $rst['teamName'];
			$cid      = $this->fm->validation($cid);
			$pid      = $this->fm->validation($pid);
			$lang     = $this->fm->validation($lang);
			$answer   = $this->fm->validation($answer);
			$teamName = $this->fm->validation($teamName);
			$userID   = $this->fm->validation($userID);
			
			$cid      = $this->db->link->real_escape_string($cid);
			$pid      = $this->db->link->real_escape_string($pid);
			$lang     = $this->db->link->real_escape_string($lang);
			$answer   = $this->db->link->real_escape_string($answer);
			$teamName = $this->db->link->real_escape_string($teamName);
			$userID   = $this->db->link->real_escape_string($userID);
			
			$sql ="INSERT INTO tbl_submission(userID,author,pID,cID,language,verdict) VALUES('$userID','$teamName','$pid','$cid','$lang','$answer')";
			$result = $this->db->insert($sql);
			return $result;
		}
		
		public function getContestRunningTime($cid){
			$sql = "SELECT CONCAT(cdate,' ',cstime) contestStime,CONCAT(cdate,' ',cetime) contestETime FROM tbl_contests 
			WHERE (CONCAT(cdate,' ',cetime)) = (SELECT MIN(CONCAT(cdate,' ',cetime)) FROM tbl_contests 
			WHERE (CONCAT(cdate,' ',cetime)) > NOW() AND status=1 AND cid='$cid')";
			$result = $this->db->select($sql);
			return $result;
		}
	}

?>