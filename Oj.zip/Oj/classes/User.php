<?php
	$path = realpath(dirname(__FILE__));
	include_once $path.'/../lib/Session.php';
	include_once $path.'/../lib/Database.php';
	include_once $path.'/../lib/format.php';
?>
<?php
	class User{
		private $db;
		private $fm;
		public function __construct(){
			$this->db = new Database();
			$this->fm = new Format();
		}
		public function randomPassword() {
			$alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
			$pass = array();
			$alphaLength = strlen($alphabet) - 1;
			for ($i = 0; $i < 10; $i++) {
				$n = rand(0, $alphaLength);
				$pass[] = $alphabet[$n];
			}
			return implode($pass);
		}
		
		public function createUser($data,$cid){
			$teamName = $this->fm->validation($data['teamName']);
			$email    = $this->fm->validation($data['email']);
			$uniName  = $this->fm->validation($data['uniName']);
			$userID   = $this->fm->validation($data['userID']);
			$pass     = $this->randomPassword();
			
			$teamName = $this->db->link->real_escape_string($teamName);
			$email    = $this->db->link->real_escape_string($email);
			$uniName  = $this->db->link->real_escape_string($uniName);
			$userID   = $this->db->link->real_escape_string($userID);
			$pass     = $this->db->link->real_escape_string($pass);
			if(empty($teamName) || empty($email) || empty($uniName) || empty($userID) || empty($pass)){
				$msg = "<span class='error'>Field Can't be Empty!!!</span>";
				return $msg;
			}else{
				$sql = "SELECT userID FROM tbl_users WHERE userID='$userID'";
				$rst = $this->db->select($sql);
				if(!$rst){
					$sql = "INSERT INTO tbl_users (teamName,email,uniName,userID,cID,password) VALUES('$teamName','$email','$uniName','$userID','$cid','$pass')";
					$result = $this->db->insert($sql);
					if($result){
						$msg = "<span class='success'>User Created Successfully.</span>";
						return $msg;
					}else{
						$msg = "<span class='error'>User doesn't Created.</span>";
						return $msg;
					}
				}else{
					$msg = "<span class='error'>User Already Created.</span>";
					return $msg;
				}
			}	
		}
		
		public function viewAllUsers($cid){
			$sql = "SELECT * FROM tbl_users WHERE cid='$cid'";
			$rst = $this->db->select($sql);
			return $rst;
		}
		
		public function deleteUser($cid,$id){
			$sql = "DELETE FROM tbl_users WHERE cid='$cid' AND uID='$id'";
			$rst = $this->db->delete($sql);
			return $rst;
		}
		
		public function userRetrieve($cid,$uid){
			$sql = "SELECT * FROM tbl_users WHERE cid='$cid' AND uid='$uid'";
			$rst = $this->db->select($sql);
			return $rst;
		}
		
		public function updateUser($data,$cid,$uid){
			$teamName = $this->fm->validation($data['teamName']);
			$email    = $this->fm->validation($data['email']);
			$uniName  = $this->fm->validation($data['uniName']);
			$userID   = $this->fm->validation($data['userID']);
			
			$teamName = $this->db->link->real_escape_string($teamName);
			$email    = $this->db->link->real_escape_string($email);
			$uniName  = $this->db->link->real_escape_string($uniName);
			$userID   = $this->db->link->real_escape_string($userID);
			
			if(empty($teamName) || empty($email) || empty($uniName) || empty($userID)){
				$msg = "<span class='error'>Field Can't be Empty!!!</span>";
				return $msg;
			}else{
				$sql = "SELECT userID FROM tbl_users WHERE userID='$userID' AND uID !='$uid'";
				$rst = $this->db->select($sql);
				if(!$rst){
					$sql    = "UPDATE tbl_users SET teamName='$teamName',email='$email',uniName='$uniName',userID='$userID' WHERE uID='$uid'";
					$result = $this->db->update($sql);
					if($result){
						$msg = "<span class='success'>User Updated Successfully.</span>";
						return $msg;
					}else{
						$msg = "<span class='error'>User doesn't Updated.</span>";
						return $msg;
					}
				}else{
					$msg = "<span class='error'>User Already Existed.</span>";
					return $msg;
				}
			}
		}
		
		public function mySubmission($userID,$cid){
			$sql = "SELECT * FROM tbl_submission WHERE cID='$cid' AND userID='$userID' ORDER BY subID DESC";
			$result = $this->db->select($sql);
			return $result;
		}
		
		public function SolveCount($pID,$cID){
			$sql = "SELECT COUNT(pID) pID FROM tbl_submission WHERE pID='$pID' AND cID='$cID' AND verdict='Accepted'";
			$result = $this->db->select($sql);
			return $result;
		}
	}