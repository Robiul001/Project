<?php
	$path = realpath(dirname(__FILE__));
	include_once $path.'/../lib/Session.php';
	if (session_status() == PHP_SESSION_NONE) {
		session_start();
	}
	include_once $path.'/../lib/Database.php';
	include_once $path.'/../lib/format.php';
?>
<?php
	class AdminLogin{
		private $db;
		private $fm;
		public function __construct(){
			$this->db = new Database();
			$this->fm = new Format();
		}
		
		public function adminlog($email,$password){
			$email    = $this->fm->validation($email);
			$password = $this->fm->validation(md5($password));
		
			$email    = mysqli_real_escape_string($this->db->link,$email);
			$password = $this->db->link->real_escape_string($password);
			if(empty($email) || empty($password)){
				$msg = "<span style='color:red;text-align:center;font-size : 18px'>Field Must Not be Empty!!!</span>";
				return $msg;
			}else{
				$query    = "SELECT * FROM tbl_admin WHERE email = '$email' AND password = '$password'";
				$result   = $this->db->select($query);
				if($result != false){
					$values = $result->fetch_assoc();
						Session::set("login",true);
						Session::set("name",$values['name']);
						//Session::set("status",$values['status']);
						//Session::set("userId",$values['id']);
						//Session::set("userRole",$values['status']);
						header("Location:index.php");
				}
				else{
					$msg = "<span style='color:red;text-align:center;font-size:18px'>Invalid Email or Password!!!</span>";
					return $msg;
				}
			}	
		}
		
		public function adminCreate($data){
			$name    = $this->fm->validation($data['name']);
			$email   = $this->fm->validation($data['email']);
			$pass    = $this->fm->validation($data['password']);
			$re_pass = $this->fm->validation($data['re_pass']);
			
			$name     = $this->db->link->real_escape_string($name);
			$email    = $this->db->link->real_escape_string($email);
			$password = $this->db->link->real_escape_string($pass);
			$re_pass  = $this->db->link->real_escape_string($re_pass);
			
			$sql 	  = "SELECT * FROM tbl_admin WHERE email='$email'";
			$dupEmail = $this->db->select($sql);
			
			if(empty($name) || empty($email) || empty($pass) || empty($re_pass)){
				$msg = "<span class='error'>Field can't be empty</span>";
				return $msg;
			}else if($password != $re_pass){
				$msg = "<span class='error'>Password didn't match.</span>";
				return $msg;
			}else if($dupEmail){
				$msg = "<span class='error'>Email isn't Valid.</span>";
				return $msg;
			}else{
				$pass = md5($password);
				$query = "INSERT INTO tbl_admin (name,email,password) VALUES('$name','$email','$pass')";
				$result = $this->db->insert($query);
				if($result){
					$msg = "<span class='success'>Admin Created Successfully.</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Admin doesn't Created.</span>";
					return $msg;
				}
			}	
		}
		
		public function viewAdmin(){
			$sql    = "SELECT *FROM tbl_admin";
			$result = $this->db->select($sql);
			return $result;
		}
		
		public function particularAdmin($id){
			$query = "SELECT *FROM tbl_admin WHERE id = '$id'";
			$result = $this->db->select($query);
			return $result;
		}
		
		public function updateAdmin($data,$id){
			$name    = $this->fm->validation($data['name']);
			$email   = $this->fm->validation($data['email']);
			$pass    = $this->fm->validation($data['password']);
			$re_pass = $this->fm->validation($data['re_pass']);
			
			$name     = $this->db->link->real_escape_string($name);
			$email    = $this->db->link->real_escape_string($email);
			$password = $this->db->link->real_escape_string($pass);
			$re_pass  = $this->db->link->real_escape_string($re_pass);
			
			if(empty($name) || empty($email) || empty($pass) || empty($re_pass)){
				$msg = "<span class='error'>Field can't be empty</span>";
				return $msg;
			}else if($password != $re_pass){
				$msg = "<span class='error'>Password didn't match.</span>";
				return $msg;
			}else{
				$pass   = md5($password);
				$sql    = "UPDATE tbl_admin SET name='$name',email='$email',password='$pass' WHERE id='$id'";
				$result = $this->db->update($sql);
				if($result){
					$msg = "<span class='success'>Admin Updated Successfully.</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Admin doesn't Updated.</span>";
					return $msg;
				}
			}
		}
		
		public function deleteAdmin($id){
			$sql    = "DELETE FROM tbl_admin WHERE id='$id'";
			$result = $this->db->delete($sql);
			return $result;
		}
		
		/*User Panel*/
		
		public function userLog($userID,$password){
			$userID    = $this->fm->validation($userID);
			$password = $this->fm->validation($password);
			
			$userID    = $this->db->link->real_escape_string($userID);
			$password = $this->db->link->real_escape_string($password);
			
			if(empty($userID) || empty($password)){
				$msg = "<span style='color:red;text-align:center;font-size : 18px'>Field Must Not be Empty!!!</span>";
				return $msg;
			}else{
				$query    = "SELECT userID,teamName FROM tbl_users WHERE userID = '$userID' AND password = '$password'";
				$result   = $this->db->select($query);
				if($result != false){
					$values = $result->fetch_assoc();
					Session::set("userID",$values['userID']);
					header("Location:index.php");
					return $result;
				}
				else{
					$msg = "<span style='color:red;text-align:center;font-size:18px'>Invalid User ID or Password!!!</span>";
					return $msg;
				}
			}
		}
		
		public function getUsername($userID){
			$userID    = $this->fm->validation($userID);
			$userID    = $this->db->link->real_escape_string($userID);
			$sql = "SELECT teamName,cID FROM tbl_users WHERE userID='$userID'";
			$rst = $this->db->select($sql);
			return $rst;
		}
		
	}

?>