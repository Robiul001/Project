<?php
	$path = realpath(dirname(__FILE__));
	include_once $path.'/../lib/Database.php';
	include_once $path.'/../lib/Format.php';
?>
<?php
	class Problemset{
		private $db;
		private $fm;
		public function __construct(){
			$this->db = new Database();
			$this->fm = new Format();
		}
		
		public function problemsetCreate($data){
			$cID          = $this->fm->validation($data['cID']);
			$pName        = $this->fm->validation($data['pName']);
			$timeLimit    = $this->fm->validation($data['timeLimit']);
			$memoryLimit  = $this->fm->validation($data['memoryLimit']);
			$totalTestcase= $this->fm->validation($data['totalTestcase']);
			$content      = $this->fm->validation($data['content']);
			
			$cID          = $this->db->link->real_escape_string($cID);
			$pName        = $this->db->link->real_escape_string($pName);
			$timeLimit    = $this->db->link->real_escape_string($timeLimit);
			$memoryLimit  = $this->db->link->real_escape_string($memoryLimit);
			$totalTestcase= $this->db->link->real_escape_string($totalTestcase);
			$content      = $this->db->link->real_escape_string($content);
			
			if(empty($pName) || empty($timeLimit) || empty($memoryLimit) || empty($totalTestcase) || empty($content)){
				$msg = "<span class='error'>Field can't be empty</span>";
				return $msg;
			}else{
				$sql    = "INSERT INTO tbl_problemset(cID,pName,timeLimit,memoryLimit,content,totalTestcase) VALUES('$cID','$pName','$timeLimit','$memoryLimit','$content','$totalTestcase')";
				$result = $this->db->insert($sql);
				if($result){
					$msg = "<span class='success'>Problemset Created Successfully.</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Problemset doesn't Created.</span>";
					return $msg;
				}
			}
		}
		
		public function allProblemsByContestId($id){
			$sql    = "SELECT * FROM tbl_problemset WHERE cID = '$id'";
			$result = $this->db->select($sql);
			return $result;
		}
		
		public function selectSpecificProblemFromContest($pid,$cid){
			$sql    = "SELECT * FROM tbl_problemset WHERE pID='$pid' AND cID='$cid'";
			$result = $this->db->select($sql);
			return $result;
		}
		
		public function updateProblem($data,$pid){
			$cID          = $this->fm->validation($data['cID']);
			$pName        = $this->fm->validation($data['pName']);
			$timeLimit    = $this->fm->validation($data['timeLimit']);
			$memoryLimit  = $this->fm->validation($data['memoryLimit']);
			$totalTestcase= $this->fm->validation($data['totalTestcase']);
			$content      = $this->fm->validation($data['content']);
			
			$cID          = $this->db->link->real_escape_string($cID);
			$pName        = $this->db->link->real_escape_string($pName);
			$timeLimit    = $this->db->link->real_escape_string($timeLimit);
			$memoryLimit  = $this->db->link->real_escape_string($memoryLimit);
			$totalTestcase= $this->db->link->real_escape_string($totalTestcase);
			$content      = $this->db->link->real_escape_string($content);
			if(empty($pName) || empty($timeLimit) || empty($memoryLimit) || empty($totalTestcase) || empty($content)){
				$msg = "<span class='error'>Field can't be empty</span>";
				return $msg;
			}else{
				$sql    = "UPDATE tbl_problemset SET pName='$pName',timeLimit='$timeLimit',memoryLimit='$memoryLimit',
				content='$content',totalTestcase='$totalTestcase' WHERE cID='$cID' AND pID='$pid'";
				$result = $this->db->update($sql);
				if($result){
					$msg = "<span class='success'>Problemset Updated Successfully.</span>";
					return $msg;
				}else{
					$msg = "<span class='error'>Problemset doesn't Updated.</span>";
					return $msg;
				}
			}
		}
		
		public function deleteProblemByID($delPid,$delCid){
			$sql    = "DELETE FROM tbl_problemset WHERE pID='$delPid' AND cID='$delCid'";
			$result = $this->db->delete($sql);
			return $result; 
		}
		
		public function lastID($cid){
			$sql = "SELECT * FROM tbl_problemset
			WHERE pID = (SELECT MAX(pID) FROM tbl_problemset)
			AND cID = $cid";
			$result = $this->db->select($sql);
			return $result;
		}
		
		/*User Panel*/
		public function problemName($pID,$cID){
			$sql = "SELECT pName FROM tbl_problemset WHERE pID='$pID' AND cID='$cID'";
			$result = $this->db->select($sql);
			return $result;
		}
		
	}