<?php
	$path = realpath(dirname(__FILE__));
	include_once $path.'/../lib/Database.php';
	include_once $path.'/../lib/Format.php';
?>
<?php
	class Testcase{
		private $db;
		private $fm;
		public function __construct(){
			$this->db = new Database();
			$this->fm = new Format();
		}
		
		public function contestAndProblemName($pid,$cid){
			$sql    = "SELECT c.cid,c.cname,p.pID,p.pName,p.totalTestcase FROM tbl_contests c INNER JOIN tbl_problemset p 
			           ON c.cid = p.cID AND c.cid=$cid AND p.pID=$pid";
			$result = $this->db->select($sql);
			return $result;
		}
		
		public function testcaseCount($pid,$cid){
			$sql    = "SELECT COUNT(pID) FROM tbl_testcase WHERE pID='$pid' AND cID='$cid'";
			$result = $this->db->select($sql);
			return $result; 
		}
		
		public function deleteTestcase($pid){
			$sql    ="DELETE FROM tbl_testcase WHERE pID='$pid'";
			$value = $this->db->delete($sql);
			return $value;
		}
		
		public function createTestcase($data){
			$pID    = $this->fm->validation($data['pID']);
			$cID    = $this->fm->validation($data['cID']);
			$input  = $this->fm->validation($data['input']);
			$output = $this->fm->validation($data['output']);
			
			$pID    = $this->db->link->real_escape_string($pID);
			$cID    = $this->db->link->real_escape_string($cID);
			$input  = $this->db->link->real_escape_string($input);
			$output = $this->db->link->real_escape_string($output);
			if(!empty($input) && !empty($output)){
				$sql    = "INSERT INTO tbl_testcase(pID,cID,input,output) 
			           VALUES('$pID','$cID','$input','$output')";
				$result = $this->db->insert($sql);
				if($result){
					return $msg="<span class='success'>Testcase Creatd Successfully.</span>";
				}else{
					return $msg="<span class='error'>Testcase Not Creatd.</span>";
				}
			}
		}
		
		/*User Panel*/
		public function retrievingTestcase($pid,$cid){
			$sql    = "SELECT * FROM tbl_testcase WHERE pID='$pid' AND cID='$cid'";
			$result = $this->db->select($sql);
			return $result; 
		}
	
	
	}