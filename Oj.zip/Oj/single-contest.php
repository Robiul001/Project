<?php 
	include_once 'inc/header.php';
	$cid = $fm->validation($_GET['cid']);
?>
  <!--Body Section-->
  <section class="my-3 content-section">
	<div class="container">
		<div class="row">
		<!--sidebar-->
		<?php include_once('inc/sidebar.php');?>
			<div class="col-lg-9 order-lg-3">
			<!--Problem Set Start-->
				<div class="card">
					<div class="card-header text-uppercase">
						<h3>Problems</h3>
					</div>
					<ul class="list-group list-group-flush">
					<!--single item start-->
				<?php
					$cAllproblem = $ps->allProblemsByContestId($cid);
					if($cAllproblem){
						while($result = $cAllproblem->fetch_assoc()){?>
						<a href="problem.php?cid=<?php echo $result['cID'] ?>&&pid=<?php echo $result['pID']; ?>"class="p-2"><li class="list-group-item">
							<div class="float-left">
								<h2><span style="padding-left:15px;font-size:23px"><?php echo $result['pName']; ?></span></h2>
							</div>
							<div class="float-right"><i class="fas fa-user"></i> x
							<?php $sCount = $ur->SolveCount($result['pID'],$result['cID'])->fetch_assoc();
							echo $sCount['pID'];?></div>
						</li></a>
					<?php } }else{ ?>
							<li class="list-group-item"><div class="text-center">
								<h2><span>Doesn't Contain Any Problem.</span></h2>
							</div></li>
					<?php } ?>
					<!--single item end-->
					</ul>
				</div>
			<!--Clarifications start-->
				<!--<div class="card pt-3">
					<div class="card-header text-uppercase">
						<h3>Clarifications<sub> (<a href="clarification-all.php">see all</a>)</sub></h3>
					</div>
					<ul class="list-group list-group-flush">
					<!--single item start-->
						<!--<a href="single-clarification.php" class="pb-2"><li class="list-group-item">
							<div class="float-left">
								<span style="padding-left:15px;font-size:18px">[A.Perfect Love ] What is your Question?</span>
								<p style="padding-left:15px;font-size:15px">Answer will be blank here as Question is ignored</p>
							</div>
							<div class="float-right">
								<span class="badge badge-pill badge-info text-capitalize">ignored</span>
							</div>
						</li></a>
					<!--single item end-->
						<!--<a href=" " class="pb-2"><li class="list-group-item">
							<div class="float-left">
								<span style="padding-left:15px;font-size:18px">[B.Sakib and His Friends ] What is your Question?</span>
								<p style="padding-left:15px;font-size:15px">Admin answer is here.</p>
							</div>
							<div class="float-right">
								<span class="badge badge-pill badge-info text-capitalize">answered</span>
							</div>
						</li></a>
					</ul>
				</div>-->
			</div>
			</div>
	
		</div>
	</div>
  </section>
  <!--End Body Section-->
<?php include_once('inc/footer.php') ?>