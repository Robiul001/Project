<?php 
	$datec = date("YYYY-MM-DD hh:mm:ss");
	$result = $ct->getContestRunningTime($cid);
	$cTime = "";
	if($result){
		$row = $result->fetch_assoc();	
		$date=date_create($row['contestETime']);
		$time=date_format($date,"M d,Y G:i:s");
		$dt = new DateTime('now', new DateTimezone('Asia/Dhaka'));
		$dtime = date_format($dt,"M d,Y G:i:s");
		$cTime = "Running";
	}else{
		$cTime = "Finished";
	}
	
?> 
<script>
  var countDownDate = new Date("<?php echo $time;?>").getTime();
  var x = setInterval(function() {
  var now = new Date().getTime();
  var distance = countDownDate - now;

  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
  document.getElementById("demo").innerHTML = + hours + ":" + minutes + ":" + seconds;
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "Finished";
  }
}, 1000);
</script>
<div class="col-lg-3 order-lg-9">
	<div class="card card1">
	<?php
		$cProblem = $ct->selectContestByID($cid)->fetch_assoc();
		if($cProblem){?>
		<div class="card-header text-uppercase text-center">
			<h4><?php echo $cProblem['cname']; ?></h4>
		</div>
		<ul class="list-group list-group-flush">
		<!--single item start-->
			<li class="list-group-item">
				<h4 class="list-group-item-heading"><?php echo $cTime; ?></h4>
				<p style="text-align:center;font-size:21px;font-weight:bold" id="demo"></p>
			</li>
		<!--single item end-->
		</ul>
		<div class="card-footer text-uppercase text-center">
			<?php if($cTime == "Running"){?><h4>Contest has been Running</h4>
			<?php }else{?>
				<h4>Contest has Finished</h4>
			<?php } ?>
		</div>
	</div>
	<?php } ?>
<?php if($userID){
	$conID = $getUser['cID'];
	if($cid == $conID){
 ?>
	<div class="card card1 mt-3">
	<?php if(isset($pid)){ ?>
		<div class="card-header text-uppercase text-center">
			<h4>Submit</h4>
		</div>
		<ul class="list-group list-group-flush">
		<!--single item end-->
	<form method="post" action="" enctype="multipart/form-data">
		<select name="language" class="list-group-item" style="width:100%">
			<option>Select Language</option>
	<?php $lanSelect = $ct->languageSelection();
		if($lanSelect){
			while($lanValue = $lanSelect->fetch_assoc()){?>
			<option value="<?php echo strtolower($lanValue['language']); ?>"><?php echo $lanValue['language'] ?></option>
	<?php } } ?>
		</select>
		<input style="margin-top:10px" type="file" name="cppcode"/>
		<button style="margin-top:10px;width:100%;padding:10px" name="problemSubmit" class="btn btn-dark" type="submit">Submit</button>
	</form>
		</ul>
	<?php } ?>
	</div>
<?php } } ?>
<?php if(isset($answer)){echo $answer;} ?>
</div>