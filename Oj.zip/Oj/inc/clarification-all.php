<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <title></title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!--<link rel="manifest" href="site.webmanifest">-->
  <!--<link rel="apple-touch-icon" href="icon.png">-->
  <!-- Place favicon.ico in the root directory -->
  
  <!--<link rel="stylesheet" href="css/normalize.css">-->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/all.min.css">
  <meta name="theme-color" content="#fafafa">
</head>

<body>
  <!--[if IE]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
  <![endif]-->

  
  
  <!-- Start of Project-->
  
  
  <!--Header section-->
  <section class="bg-secondary">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<nav class="navbar navbar-expand-sm navbar-light bg-secondary">
					<a href="index.php" class="navbar-brand text-white"><strong>DUETOJ</strong><sup>&beta;</sup></a>
					<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
						<span class="navbar-toggler-icon"></span>
					</button>

					<div class="collapse navbar-collapse justify-content-between text-uppercase" id="navbarCollapse" style="font-size:13px">
						<div class="navbar-nav">
							<a href="contest.php" class="nav-item nav-link">Contests</a>
							<a href="problem.php" class="nav-item nav-link">Dashboard</a>
							<a href="clarification-all.php" class="nav-item nav-link">Clarifications</a>
							<a href="problem.php" class="nav-item nav-link">Standing</a>
							<a href="problem.php" class="nav-item nav-link">Submission</a>
						</div>
						<div class="navbar-nav">
							<a href="login.php" class="nav-item nav-link">Login</a>
						</div>
					</div>
				</nav>
			</div>
		</div>
	</div>
  </section>
  <!--End Header Section-->
  
  
  <!--Body Section-->
  <section class="my-3 ">
	<div class="container">
		<div class="row">
			<div class="col-lg-3 order-lg-9">
				<div class="card card1">
					<div class="card-header text-uppercase text-center">
						<h4>DHAKA REGIONAL TEST BY SEU ADMINSTRATORS</h4>
					</div>
					<ul class="list-group list-group-flush">
					<!--single item start-->
						<li class="list-group-item">
							<h4 class="list-group-item-heading">Running</h4>
						</li>
					<!--single item end-->
					</ul>
					<div class="card-footer text-uppercase text-center">
						<h4>Contest has finished</h4>
					</div>
				</div>
				
				<div class="card card1 mt-3 mb-3">
					<div class="card-header text-uppercase text-center">
						<h4>Disclaimer</h4>
					</div>
					<ul class="list-group list-group-flush">
					<!--single item start-->
						<li class="list-group-item">
							<p class="list-group-item-heading" style="font-size:14px;text-align:left">CodeMarshal is serving as a hosting platform for this contest 
							and does not claim to own its content. To report copyright violations drop a line at: info@codemarshal.com</p>
						</li>
					<!--single item end-->
					</ul>
				</div>
				
				<div class="card card1">
					<div class="card-header text-uppercase text-center">
						<h4>Practice</h4>
					</div>
					<ul class="list-group list-group-flush">
					<!--single item start-->
						<li class="list-group-item">
							<p class="list-group-item-heading" style="font-size:14px;text-align:left">Solve these problems in practice mode.</p>
						<center><button style="width:100%;padding:10px" class="btn btn-dark" type="button">Login</button></center>
						</li>
						
					<!--single item end-->
					</ul>
				</div>
			</div>
			<div class="col-lg-9 order-lg-3">
				<div class="card">
					<div class="card-header text-uppercase">
						<h3>Clarifications</h3>
					</div>
					<ul class="list-group list-group-flush">
					<!--single item start-->
						<a href="single-clarification.php" class="pb-2"><li class="list-group-item">
							<div class="float-left">
								<span style="padding-left:15px;font-size:18px">[A.Perfect Love ] What is your Question?</span>
								<p style="padding-left:15px;font-size:15px">Answer will be blank here as Question is ignored</p>
							</div>
							<div class="float-right">
								<span class="badge badge-pill badge-info text-capitalize">ignored</span>
							</div>
						</li></a>
					<!--single item end-->
						<a href=" " class="pb-2"><li class="list-group-item">
							<div class="float-left">
								<span style="padding-left:15px;font-size:18px">[B.Sakib and His Friends ] What is your Question?</span>
								<p style="padding-left:15px;font-size:15px">Admin answer is here.</p>
							</div>
							<div class="float-right">
								<span class="badge badge-pill badge-info text-capitalize">answered</span>
							</div>
						</li></a>
					</ul>
				</div>
				
				<!--Pagination Section-->
				<section class="pagination mt-5">
					<div class="container">
						<div class="row justify-content-center align-items-center">
							<nav aria-label="Page navigation example">
								<ul class="pagination">
									<li class="page-item">
										<a class="page-link" href="#" aria-label="Previous">
											<span aria-hidden="true">&laquo;</span>
											<span class="sr-only">Previous</span>
										</a>
									</li>
									<li class="page-item"><a class="page-link" href="#">1</a></li>
									<li class="page-item"><a class="page-link" href="#">2</a></li>
									<li class="page-item"><a class="page-link" href="#">3</a></li>
									<li class="page-item"><a class="page-link" href="#">4</a></li>
									<li class="page-item">
										 <a class="page-link" href="#" aria-label="Next">
											<span aria-hidden="true">&raquo;</span>
											<span class="sr-only">Next</span>
										 </a>
									</li>
								</ul>
							</nav>
						</div>
					</div>
			  </section>
  <!--End Pagination Section-->
				
			</div>
		</div>
	</div>
  </section>
  <!--End Body Section-->
  
  
  <!--Footer Section-->
  <section class="footer pt-5 pb-3">
	<div class="container">
		<div class="row">
			<div class="col-6 text-left text-muted">&copy; 2019 DUETOJ <a href="https://www.facebook.com" style="color:#658733"><i class="fab fa-facebook-f pl-3"></i></a></div>
			<div class="col-6 text-right text-muted">Developed By RRP</div>
		</div>
	</div>
  </section>
  <!--End Footer Section-->
  
  
 
  <!--End of Project-->
  
  
  
  <!--------Script is here---------->

	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>
