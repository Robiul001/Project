<!--Footer Section-->
  <section class="footer pt-5 pb-3">
	<div class="container">
		<div class="row">
			<div class="col-6 text-left text-muted">&copy; 2019 DUETOJ <a href="https://www.facebook.com" style="color:#658733"><i class="fab fa-facebook-f pl-3"></i></a></div>
			<div class="col-6 text-right text-muted">Developed By RRP</div>
		</div>
	</div>
  </section>
  <!--End Footer Section-->
  
  
 
  <!--End of Project-->
  
  
  
  <!--------Script is here---------->

	<script src="js/jquery-3.3.1.slim.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>

</html>
