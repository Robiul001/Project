<?php 
	include_once 'lib/Session.php';
	$path = realpath(dirname(__FILE__));
	//include_once 'inc/header.php';
	include_once 'lib/Format.php';
	include_once($path.'/../classes/Contests.php');
	include_once($path.'/Problemset.php');
	include_once($path.'/Testcase.php');
	include_once($path.'/User.php');
	include_once($path.'/AdminLogin.php');
	
?>
<?php
	$ct = new Contests();
	$ps = new Problemset();
	$fm = new Format();
	$tc = new Testcase();
	$ur = new User();
	$al = new AdminLogin();
	
	if(isset($_GET['logout'])){
		session_destroy();
		header('Location: index.php');
	}
?>
<!doctype html>
<html class="no-js" lang="">

<head>
  <meta charset="utf-8">
  <title></title>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!--<link rel="manifest" href="site.webmanifest">-->
  <!--<link rel="apple-touch-icon" href="icon.png">-->
  <!-- Place favicon.ico in the root directory -->
  
  <!--<link rel="stylesheet" href="css/normalize.css">-->
<link rel="stylesheet" href="css/bootstrap.min.css" >
  
  <link rel="stylesheet" href="css/style.css">
  <link rel="stylesheet" href="css/all.min.css">
  <meta name="theme-color" content="#fafafa">
  
<style>	
.content-section{
	min-height:600px
}
table td, .table th {
    padding: 3px !important;
    vertical-align: top;
    border-top: 1px solid #dee2e6;
}
a.noclick{
  pointer-events: none;
}
</style>
</head>

<body>
  <!--[if IE]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="https://browsehappy.com/">upgrade your browser</a> to improve your experience and security.</p>
  <![endif]-->

  
  
  <!-- Start of Project-->
  
  
  <!--Header section-->
  <section class="bg-secondary">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<nav class="navbar navbar-expand-sm navbar-light bg-secondary">
					<a href="index.php" class="navbar-brand text-white"><strong>DUETOJ</strong><sup>&beta;</sup></a>
					<button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
						<span class="navbar-toggler-icon"></span>
					</button>

					<div class="collapse navbar-collapse justify-content-between text-uppercase" id="navbarCollapse" style="font-size:13px">
						<div class="navbar-nav">
							<a href="contest.php" class="nav-item nav-link">Contests</a>
					<?php
						if(isset($_GET['cid'])){?>
							<a href="single-contest.php?cid=<?php echo $_GET['cid']; ?>" class="nav-item nav-link">Dashboard</a>
							<!--<a href="clarification-all.php" class="nav-item nav-link">Clarifications</a>-->
							<a href="standing.php" class="nav-item nav-link">Standing</a>
							<a href="submission.php?cid=<?php echo $_GET['cid'] ?>" class="nav-item nav-link">Submission</a>
						<?php }else{?>		
							<!--<a href="problems.php" class="nav-item nav-link">Problems</a>-->
						<?php } ?>
						</div>
						<div class="navbar-nav">
						<?php $userID=Session::get('userID');
						if(isset($userID)){
							$getUser = $al->getUsername($userID);
							if($getUser){
								$getUser = $getUser->fetch_assoc();
						?><p style="padding-top:8px;color:white;padding-right:20px;"><?php echo $getUser['teamName']; ?></p><a href="?logout=logout" class="nav-item nav-link"> Logout</a>
						<?php }else{?>
						<a href="login.php" class="nav-item nav-link">Login</a>
						<?php } }?> 
						</div>
					</div>
				</nav>
			</div>
		</div>
	</div>
  </section>
  <!--End Header Section-->
  