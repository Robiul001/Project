Database Name : 'db_duetoj'

dashboard url: http://localhost/Oj/dashboard/
admin login : monzurulamin10@gmail.com
password : 123


Have to Update
=========================
1.Standing
2.Super Admin/Sub Admin
3.Save User code in folder and save path in database
4.Clarification
5.Have to show Individual Submission and All Submission for specific Contest.
6.Practice Problem have to add
7.Session have to handle for Dashboard and User Login
8.User Profile in Admin Panel
9.Dynamic Title for every single page
10. URL controlling.
11.htaccess and Other folder's security Ensuring