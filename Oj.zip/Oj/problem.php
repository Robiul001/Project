<?php 
	include_once 'inc/header.php';
	$cid = $fm->validation($_GET['cid']);
	$pid = $fm->validation($_GET['pid']);
	if(!$userID){
		echo "<script>window.location='login.php'</script>";
	}
	$answer="";	
	if($_SERVER['REQUEST_METHOD'] == "POST" && isset($_POST['problemSubmit'])){
		$path = realpath(dirname(__FILE__));
		$language = $_POST['language'];
		$lang     = strtoupper($language);
		$ext = strtolower(end(explode(".",$_FILES['cppcode']['name'])));
		if(!empty($language) AND !empty($ext)){
			if(strpos($language,"c++") !=false){
				$language = "cpp";
			}
			if($language != $ext){
				$answer = "Compilation Error";
			}else{
				$current = "test.".$ext;
				$path = $path."/dashboard/testcase/contest$cid/problem$pid/";
				chdir($path);
				$current=$path.$current;
				move_uploaded_file($_FILES["cppcode"]["tmp_name"],$current);
				
				$search      = "int main(){";
				$line_number = false;
				$check = false;

				if ($handle = fopen($path."test.".$ext, "r")) {
				   $count = 0;
				   while (($line = fgets($handle, 4096)) !== FALSE and !$line_number) {
					  $count++;
					  $line_number = (strpos($line, $search) !== FALSE) ? $count : $line_number;
				   }
				   fclose($handle);
				}
				if($line_number!=0){
					$check = true;
					$replacement = "freopen(\"in.txt\",\"r\",stdin);\nfreopen(\"out.txt\",\"w\",stdout);";
					$specific_line = $line_number;
					$contents = file($path.'test.'.$ext, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
					if($specific_line > sizeof($contents)) {
						$specific_line = sizeof($contents) + 1;
					}
					array_splice($contents, $specific_line, 0, array($replacement));
					$contents = implode("\n", $contents);
					file_put_contents($path.'test.'.$ext, $contents);
				}
		//for int main(){
				if($check==false){
					$search      = "int main()";
					$line_number = false;

					if ($handle = fopen($path."test.".$ext, "r")) {
					   $count = 0;
					   while (($line = fgets($handle, 4096)) !== FALSE and !$line_number) {
						  $count++;
						  $line_number = (strpos($line, $search) !== FALSE) ? $count : $line_number;
					   }
					   fclose($handle);
					}
					if($line_number!=0){
						$replacement = "freopen(\"in.txt\",\"r\",stdin);\nfreopen(\"out.txt\",\"w\",stdout);";
						$specific_line = $line_number+1;
						$contents = file($path.'test.'.$ext, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
						if($specific_line > sizeof($contents)) {
							$specific_line = sizeof($contents) + 1;
						}
						array_splice($contents, $specific_line, 0, array($replacement));
						$contents = implode("\n", $contents);
						file_put_contents($path.'test.'.$ext, $contents);
					}
				}
				putenv("PATH=C:\Program Files (x86)\CodeBlocks\MinGW\bin");
				shell_exec("g++ ".$path."test.".$ext." -std=c++17 -o ".$path."test.exe");
				$answer = shell_exec($path."test.exe"); 
				
				/*For two file match or not*/
				function identical($fileOne, $fileTwo){
				if (filetype($fileOne) !== filetype($fileTwo)) return false;
				if (filesize($fileOne) !== filesize($fileTwo)) return false;
			 
				if (! $fp1 = fopen($fileOne, 'rb')) return false;
			 
				if (! $fp2 = fopen($fileTwo, 'rb')){
					fclose($fp1);
					return false;
				}
		 
				$same = true;
			 
				while (! feof($fp1) and ! feof($fp2))
					if (fread($fp1, 4096) !== fread($fp2, 4096)){
						$same = false;
						break;
					}
			 
				if (feof($fp1) !== feof($fp2)) $same = false;
		 
				fclose($fp1);
				fclose($fp2);
		 
				return $same;
			}
			$verdict = identical($path."judgeout.txt",$path."out.txt");
				if($verdict){
					$answer="Accepted";
				}else{
					$answer="Wrong Answer";
				}
			}
			$submit = $ct->submission($cid,$pid,$lang,$answer,$userID);
			if($submit){
				echo "<script>window.location='submission.php?cid=$cid'</script>";
			}
		
		}
	}
		
?>
  <!--Body Section-->
  <section class="my-3 ">
	<div class="container">
		<div class="row">
		<!--sidebar-->
		<?php include_once('inc/sidebar.php'); ?>
			<div class="col-lg-9 order-lg-3">
				<div class="manual">
			<?php
				$pDesc = $ps->selectSpecificProblemFromContest($pid,$cid)->fetch_assoc();
				if($pDesc){?>
					<div class="problem-header">
						<h4 class="text-center"><?php echo $pDesc['pName']; ?></h4>
						<p class="text-center">time limit per test: 
							<?php if($pDesc['timeLimit']>1){echo $pDesc['timeLimit']." seconds";}else{echo $pDesc['timeLimit']." second";} ?></p> <!--If 1 then second and if greater than 1 then seconds-->
						<p class="text-center">memory limit per test: <?php echo $pDesc['memoryLimit'];?> mb</p>
						<p class="text-center">input: standard input</p>
						<p class="text-center">output: standard output</p><br>
					</div>
					
					<div class="problem-body">
					
					<?php echo htmlspecialchars_decode($pDesc['content']); } ?>		
						<h4>Sample</h4>
						<div class="container">
							<div class="row">
								<!--Input Output table-->
								<table class="table table-borderless">
								  <thead style="border-bottom:2px solid #BABDC0">
									<tr>
									  <th scope="col">Input</th>
									  <th scope="col">Output</th>
									</tr>
								  </thead>
								  <tbody>
					<?php
						$tcCount = $tc->testcaseCount($pid,$cid)->fetch_assoc();
					?>
									<tr>
										<td><?php echo $tcCount['COUNT(pID)']; ?></td>
										<td></td>
									</tr>
					<?php
						$rTc = $tc->retrievingTestcase($pid,$cid);
						if($rTc){
							while($resultTestcase = $rTc->fetch_assoc()){?>
									<tr>
										<td><?php echo $resultTestcase['input'];?></td>
										<td><?php echo $resultTestcase['output'];?></td>
									</tr>
					<?php } }?>
								  </tbody>
								</table>
							</div>
						</div>	
					</div>	
				</div>
				
			</div>
		</div>
	</div>
  </section>
  <!--End Body Section-->
  
  
  <!--Footer Section-->
  <section class="footer pt-5 pb-3">
	<div class="container">
		<div class="row">
			<div class="col-6 text-left text-muted">&copy; 2019 DUETOJ <a href="https://www.facebook.com" style="color:#658733"><i class="fab fa-facebook-f pl-3"></i></a></div>
			<div class="col-6 text-right text-muted">Developed By RRP</div>
		</div>
	</div>
  </section>
  <!--End Footer Section-->
  
  
 
  <!--End of Project-->
  
  
  
  <!--------Script is here---------->

	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>
