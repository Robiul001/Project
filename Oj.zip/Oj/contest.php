<?php 
	include_once 'inc/header.php';
?>
  <!--Body Section-->
  <section class="my-3 content-section">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-header text-uppercase">
						<h3>contest</h3>
					</div>
					<ul class="list-group list-group-flush">
					<!--single item start-->
					<?php
						$all = $ct->viewAllActiveContest();
						if($all){
							while($result = $all->fetch_assoc()){
					?>
						<a href="single-contest.php?cid=<?php echo $result['cid']; ?>" class="<?php if(date_format(date_create($result['cdate']),"Y-m-d G:i:s") >= date('Y-m-d G:i:s'))echo "noclick " ?>pb-2"><li class="list-group-item">
							<div class="float-left">
								<h4 class="list-group-item-heading"><?php echo $result['cname']; ?></h4>
								<p class="list-group-item-text">
									<?php
									   echo date_format(date_create($result['cdate']),"M d Y");
									   echo " ".date('H:i', strtotime($result['cstime']));
									   echo "--".date('H:i', strtotime($result['cetime']));
									?>
								</p>
							</div>
							<!--<div class="float-right">
								<span class="badge badge-pill badge-info text-capitalize"> Running </span>
							</div>	-->
						</li></a>
						<?php } } ?>
					<!--single item end-->
						
					</ul>
				</div>
			</div>
		</div>
	</div>
  </section>
  <!--End Body Section-->
  
  
  <!--Pagination Section-->
  <section class="pagination">
	<div class="container">
		<div class="row justify-content-center align-items-center">
			<nav aria-label="Page navigation example">
				<ul class="pagination">
					<li class="page-item">
						<a class="page-link" href="#" aria-label="Previous">
							<span aria-hidden="true">&laquo;</span>
							<span class="sr-only">Previous</span>
						</a>
					</li>
					<li class="page-item"><a class="page-link" href="#">1</a></li>
					<li class="page-item"><a class="page-link" href="#">2</a></li>
					<li class="page-item"><a class="page-link" href="#">3</a></li>
					<li class="page-item"><a class="page-link" href="#">4</a></li>
					<li class="page-item"><a class="page-link" href="#">5</a></li>
					<li class="page-item"><a class="page-link" href="#">6</a></li>
					<li class="page-item">
						 <a class="page-link" href="#" aria-label="Next">
							<span aria-hidden="true">&raquo;</span>
							<span class="sr-only">Next</span>
						 </a>
					</li>
			    </ul>
            </nav>
		</div>
	</div>
  </section>
  <!--End Pagination Section-->
  
  
  <!--Footer Section-->
  <section class="footer pt-5 pb-3">
	<div class="container">
		<div class="row">
			<div class="col-6 text-left text-muted">&copy; 2019 DUETOJ <a href="https://www.facebook.com" style="color:#658733"><i class="fab fa-facebook-f pl-3"></i></a></div>
			<div class="col-6 text-right text-muted">Developed By RRP</div>
		</div>
	</div>
  </section>
  <!--End Footer Section-->
  
  
 
  <!--End of Project-->
  
  
  
  <!--------Script is here---------->

	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>

</html>
