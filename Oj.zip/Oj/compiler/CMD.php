<?php

$answer="";

if(isset($_POST['submit'])){
	$path = realpath(dirname(__FILE__));
	$ext = end(explode(".",$_FILES['cppcode']['name']));
	$current = "hello.".$ext;
	$path = $path."/../cppcheck/";
	chdir($path);
	$current=$path.$current;
	move_uploaded_file($_FILES["cppcode"]["tmp_name"],$current);
		
		
		
	$search      = "int main(){";
	$line_number = false;
	$check = false;

	if ($handle = fopen($path."hello.cpp", "r")) {
	   $count = 0;
	   while (($line = fgets($handle, 4096)) !== FALSE and !$line_number) {
		  $count++;
		  $line_number = (strpos($line, $search) !== FALSE) ? $count : $line_number;
	   }
	   fclose($handle);
	}
	if($line_number!=0){
		$check = true;
		$replacement = "freopen(\"in.txt\",\"r\",stdin);\nfreopen(\"out.txt\",\"w\",stdout);";
		$specific_line = $line_number;
		$contents = file('../cppcheck/hello.cpp', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
		if($specific_line > sizeof($contents)) {
			$specific_line = sizeof($contents) + 1;
		}
		array_splice($contents, $specific_line, 0, array($replacement));
		$contents = implode("\n", $contents);
		file_put_contents($path.'hello.cpp', $contents);
	}
//for int main(){
	if($check==false){
		$search      = "int main()";
		$line_number = false;

		if ($handle = fopen($path."hello.cpp", "r")) {
		   $count = 0;
		   while (($line = fgets($handle, 4096)) !== FALSE and !$line_number) {
			  $count++;
			  $line_number = (strpos($line, $search) !== FALSE) ? $count : $line_number;
		   }
		   fclose($handle);
		}
		if($line_number!=0){
			$replacement = "freopen(\"in.txt\",\"r\",stdin);\nfreopen(\"out.txt\",\"w\",stdout);";
			$specific_line = $line_number+1;
			$contents = file('../cppcheck/hello.cpp', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
			if($specific_line > sizeof($contents)) {
				$specific_line = sizeof($contents) + 1;
			}
			array_splice($contents, $specific_line, 0, array($replacement));
			$contents = implode("\n", $contents);
			file_put_contents($path.'hello.cpp', $contents);
		}
	}
	putenv("PATH=C:\Program Files (x86)\CodeBlocks\MinGW\bin");
	shell_exec("g++ G:/xamppserver/htdocs/cppcheck/hello.cpp -std=c++17 -o G:/xamppserver/htdocs/cppcheck/hello.exe");
	$answer = shell_exec("G:/xamppserver/htdocs/cppcheck/hello.exe"); 
	
	/*For two file match or not*/
	function identical($fileOne, $fileTwo){
    if (filetype($fileOne) !== filetype($fileTwo)) return false;
    if (filesize($fileOne) !== filesize($fileTwo)) return false;
 
    if (! $fp1 = fopen($fileOne, 'rb')) return false;
 
    if (! $fp2 = fopen($fileTwo, 'rb'))
    {
        fclose($fp1);
        return false;
    }
 
    $same = true;
 
    while (! feof($fp1) and ! feof($fp2))
        if (fread($fp1, 4096) !== fread($fp2, 4096))
        {
            $same = false;
            break;
        }
 
    if (feof($fp1) !== feof($fp2)) $same = false;
 
    fclose($fp1);
    fclose($fp2);
 
    return $same;
}
$verdict = identical($path."judgeout.txt",$path."out.txt");
	if($verdict){
		$answer="Accepted";
	}else{
		$answer="Wrong Answer";
	}
}	
?>


<style>

	.txtarea{
		
		resize:none;
		outline:none;
		
		width: 300px;
		height: 400px;
		border: 3px; solid #cccccc;
		padding : 5px; font-family: Tahona,sans-serif;
		background-position: bottom-right;
		background-repeat : no-repeat;
		font-size: 25px;
		color: #FFFFFF;
	}
	</style>
	
	<form method = "POST" action="" enctype="multipart/form-data">
		<input name="cppcode" type="file">
		<!--<textarea name="cppcode" style = "background:red;" placeholder="Enter c++ code" class="txtarea"><?php echo $current; ?></textarea>-->
		<input name="submit" type="Submit" value="Run By MKS>>>">
		<textarea name="cppcode2" style="background:blue;" disabled class="txtarea" placeholder="See Result"><?php echo $answer; ?></textarea>
	</form>	