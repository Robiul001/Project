<?php 
	include_once 'inc/header.php';
	$cid = $fm->validation($_GET['cid']);
?>
  <!--Body Section-->
  <section class="my-3 content-section">
	<div class="container">
		<div class="row">
		<!--sidebar-->
			<?php include_once('inc/sidebar.php'); ?>
			<div class="col-lg-9 order-lg-3">
			<!--Problem Set Start-->
				<div class="card">
					<div class="card-header text-uppercase">
						<h3>Contest Submissions</h3>
					</div>
					<ul class="list-group list-group-flush">
						<table class="text-center align-items-center table table-striped">
						<thead>
						  <tr>
							<th>#</th>
							<th>Author</th>
							<th>Problem</th>
							<th>Time</th>
							<th>Language</th>
							<th></th>
						  </tr>
						</thead>
						<tbody>
					<?php
						$submission = $ur->mySubmission($userID,$cid);
						if($submission){
							while($result = $submission->fetch_assoc()){
								$pName = $ps->problemName($result['pID'],$result['cID'])->fetch_assoc();?>
						  <tr>
							<td><?php echo $result['subID']; ?></td>
							<td><?php echo $result['author']; ?></td>
							<td><?php echo $pName['pName']; ?></td>
							<td><?php $date = date_create($result['time']); echo date_format($date,"M d,Y h:i:s A") ?></td>
							<td><?php echo $result['language']; ?></td>
							<td>
							<?php 
								if($result['verdict'] == "Accepted"){ ?>
								<p style="font-size:16px" class="text-white badge badge-success">Accepted</p>
							<?php }else if($result['verdict'] == "Compilation Error"){ ?>	
								<p style="font-size:14px" class="text-white badge badge-warning">Compilation Error</p>
							<?php }else if($result['verdict'] == "Wrong Answer"){ ?>
								<p style="font-size:15px" class="text-white badge badge-danger">Wrong Answer</p>
							<?php } ?>
							</td>
						  </tr>
					<?php } } ?>
						</tbody>
					  </table>
					<!--single item end-->
					</ul>
				</div>
			<!--Clarifications start-->
				<!--<div class="card pt-3">
					<div class="card-header text-uppercase">
						<h3>Clarifications<sub> (<a href="clarification-all.php">see all</a>)</sub></h3>
					</div>
					<ul class="list-group list-group-flush">
					<!--single item start-->
						<!--<a href="single-clarification.php" class="pb-2"><li class="list-group-item">
							<div class="float-left">
								<span style="padding-left:15px;font-size:18px">[A.Perfect Love ] What is your Question?</span>
								<p style="padding-left:15px;font-size:15px">Answer will be blank here as Question is ignored</p>
							</div>
							<div class="float-right">
								<span class="badge badge-pill badge-info text-capitalize">ignored</span>
							</div>
						</li></a>
					<!--single item end-->
						<!--<a href=" " class="pb-2"><li class="list-group-item">
							<div class="float-left">
								<span style="padding-left:15px;font-size:18px">[B.Sakib and His Friends ] What is your Question?</span>
								<p style="padding-left:15px;font-size:15px">Admin answer is here.</p>
							</div>
							<div class="float-right">
								<span class="badge badge-pill badge-info text-capitalize">answered</span>
							</div>
						</li></a>
					</ul>
				</div>-->
			</div>
			</div>
	
		</div>
	</div>
  </section>
  <!--End Body Section-->
<?php include_once('inc/footer.php'); ?>